import unsloth
from unsloth import FastLanguageModel, is_bfloat16_supported
import os
import json
import re
import threading
import time
import datetime
import shutil
import contextlib
import collections
import gc
import uuid
import traceback
import hashlib

import torch
import pynvml
import anthropic
from flask import Flask, request, jsonify, Response
from werkzeug.utils import secure_filename
from threading import Thread
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics import silhouette_score


import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.cluster import DBSCAN, KMeans
from collections import defaultdict


# --- THƯ VIỆN AI ---

from datasets import load_dataset
from trl import SFTTrainer,SFTConfig
# from trl import DataCollatorForCompletionOnlyLM


from transformers import TrainingArguments, TrainerCallback, TextIteratorStreamer
from huggingface_hub import login, HfApi, snapshot_download

# ======================================================================
# 0. DOCKER SECRETS HELPER
# Ưu tiên đọc từ /run/secrets/<name> (Docker Swarm Secrets)
# Fallback sang os.environ nếu không có (local dev / docker compose)
# ======================================================================
def _read_secret(name: str, default: str = "") -> str:
    """
    Đọc secret theo thứ tự ưu tiên:
      1. File /run/secrets/<name>  — Docker Swarm Secret
      2. Biến môi trường <name>    — docker-compose / local dev
      3. default
    """
    secret_path = f"/run/secrets/{name}"
    try:
        if os.path.isfile(secret_path):
            with open(secret_path, "r", encoding="utf-8") as f:
                value = f.read().strip()
            if value:
                return value
    except Exception:
        pass
    return os.environ.get(name, default)


# 0. CÀI ĐẶT MÔI TRƯỜNG
os.environ["TORCHDYNAMO_DISABLE"] = "1"
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'

app = Flask(__name__)
UPLOAD_FOLDER = './dataset_uploads'
LOCAL_CHECKPOINT_BASE = "/tmp/checkpoints_"

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(LOCAL_CHECKPOINT_BASE, exist_ok=True)

jobs_db = {}
job_queue = collections.deque()
active_training_jobs = set()
MAX_CONCURRENT_JOBS = 1  # 1 GPU Colab runs only 1 job at a time

pynvml.nvmlInit()
gpu_handle = pynvml.nvmlDeviceGetHandleByIndex(0)

# Biến toàn cục cho inference cache và watchdog
_current_infer_model = None
_current_infer_tokenizer = None
_current_infer_model_id = None
last_heartbeat = time.time()

# ── Multi-slot model registry (instanceId → slot) ──────────────────
# Mỗi slot giữ 1 bộ (model, tokenizer, model_id) độc lập.
# instanceId=1 → slot 1  |  instanceId=2 → slot 2
_model_slots: dict = {}          # {slot_id: {"model", "tokenizer", "model_id"}}
_slot_locks: dict = {            # lock riêng per-slot — tránh race condition
    1: threading.Lock(),
    2: threading.Lock(),
}

from transformers import StoppingCriteria, StoppingCriteriaList
_slot_abort_events = {1: threading.Event(), 2: threading.Event()}

class AbortStoppingCriteria(StoppingCriteria):
    def __init__(self, event: threading.Event):
        self.event = event
    def __call__(self, input_ids, scores, **kwargs) -> bool:
        return self.event.is_set()

last_heartbeat = time.time()
inference_logs_db = {}

# Giải phóng bộ nhớ GPU cho 1 slot cụ thể
def _release_slot(slot_id: int):
    slot = _model_slots.pop(slot_id, None)
    if slot is None:
        return
    del slot["model"]
    del slot["tokenizer"]
    gc.collect()
    torch.cuda.empty_cache()
    print(f"\n--- Slot {slot_id}: GPU memory released ---\n")

# Giải phóng toàn bộ slots (backward-compat helper)
def _release_gpu_memory():
    for sid in list(_model_slots.keys()):
        _release_slot(sid)

def get_gpu_stats():
    """Lấy thông số sử dụng GPU và VRAM hiện tại."""
    try:
        info = pynvml.nvmlDeviceGetMemoryInfo(gpu_handle)
        vram_used_mb = info.used // (1024 * 1024)
        vram_total_mb = info.total // (1024 * 1024)
        util = pynvml.nvmlDeviceGetUtilizationRates(gpu_handle)
        gpu_util = util.gpu
        return vram_used_mb, vram_total_mb, gpu_util
    except:
        return 0, 0, 0

# ======================================================================


# ======================================================================
# SLOT MANAGEMENT — giới hạn eval jobs concurrent trên GPU
# ======================================================================

# T4 16GB: mỗi model 7B-4bit ~5GB → tối đa 3 slot
# Khi lên H100 chỉ cần đổi con số này
GPU_EVAL_SLOTS = 3
_eval_semaphore = threading.Semaphore(GPU_EVAL_SLOTS)
_active_eval_count = 0
_active_eval_lock  = threading.Lock()

def _eval_slot_acquire() -> bool:
    """Thử lấy slot. Trả về True nếu thành công, False nếu tất cả slot đang bận."""
    acquired = _eval_semaphore.acquire(blocking=False)
    if acquired:
        global _active_eval_count
        with _active_eval_lock:
            _active_eval_count += 1
    return acquired

def _eval_slot_release():
    """Giải phóng slot sau khi eval xong (dù thành công hay lỗi)."""
    global _active_eval_count
    with _active_eval_lock:
        _active_eval_count = max(0, _active_eval_count - 1)
    _eval_semaphore.release()

print('✅ Slot management ready')

# ======================================================================



# ======================================================================
# 1. CUSTOM CALLBACKS (CONSOLIDATED)
# ======================================================================
class FlaskProgressCallback(TrainerCallback):
    def __init__(self, job_id):
        self.job_id = job_id
        self.start_time = None
        self.last_loss = 0.0
    def on_step_begin(self, args, state, control, **kwargs):
        if self.start_time is None:
            self.start_time = time.time()

    def on_log(self, args, state, control, logs=None, **kwargs):

        if not logs: return
        is_final_loss = 'train_loss' in logs
        if 'loss' in logs:
            self.last_loss = logs['loss']
        # elif 'train_loss' in logs:
        elif is_final_loss:
            self.last_loss = logs['train_loss']

        # --- PHẦN GIỮ NGUYÊN CODE CŨ CỦA BẠN ---
        loss_val = self.last_loss
        eval_loss_val = logs.get('eval_loss', 0)
        accuracy_val = round(logs.get("accuracy", 0) * 100, 2) if "accuracy" in logs else 0
        epoch_val = round(state.epoch or 0, 2)
        vram_used, _, gpu_util = get_gpu_stats()


        # Tính toán avg_step_time cho ETA (Giữ nguyên)
        avg_step_time = 0
        if self.start_time and state.global_step > 0:
            avg_step_time = (time.time() - self.start_time) / state.global_step

        # --- PHẦN BỔ SUNG ĐỂ TÍNH OVERFIT ---
        eval_loss = round(logs.get("eval_loss", 0), 4) if "eval_loss" in logs else None

        # Cập nhật dữ liệu cho Frontend (Bổ sung eval_loss vào metrics)
        update_payload = {
            'loss': loss_val,
            'epoch': epoch_val,
            'progress': round((state.global_step / state.max_steps) * 100, 2) if state.max_steps > 0 else 0,
            'avg_step_time': round(avg_step_time, 2),
            'total_steps_per_epoch': state.max_steps // max(1, int(state.epoch)) if state.epoch and state.epoch > 0 else state.max_steps,
            'metrics': {
                'loss': loss_val,
                'eval_loss': eval_loss_val,
                'accuracy': accuracy_val,
                'vram': vram_used,
                'gpu_util': gpu_util
            }
        }

        # Nếu có Eval Loss (kết quả thi thử), gửi kèm về để vẽ biểu đồ Overfit
        if eval_loss is not None:
            update_payload['metrics']['eval_loss'] = eval_loss

        jobs_db[self.job_id].update(update_payload)

        # Ghi log dòng Step (Bổ sung hiển thị Eval Loss nếu có)
        log_line = f"Step {state.global_step} | Epoch {epoch_val} | Loss: {loss_val:.4f}"
        if eval_loss:
            log_line += f" | Eval Loss (Overfit): {eval_loss:.4f}"

        if 'logs' not in jobs_db[self.job_id]: jobs_db[self.job_id]['logs'] = []
        jobs_db[self.job_id]['logs'].append(log_line)

    def on_save(self, args, state, control, **kwargs):
        # Giữ nguyên phần save checkpoint của bạn
        checkpoint_msg = f"💾 Checkpoint saved locally at step {state.global_step}."
        if 'logs' not in jobs_db[self.job_id]: jobs_db[self.job_id]['logs'] = []
        jobs_db[self.job_id]['logs'].append(checkpoint_msg)

class EnhancedWatchdogCallback(TrainerCallback):
    def __init__(self, job_id):
        self.job_id = job_id

    def on_step_end(self, args, state, control, **kwargs):
        if time.time() - last_heartbeat > 30:
            print("⚠️ Watchdog: No heartbeat detected for 30s. Stopping...")
            control.should_training_stop = True

        if jobs_db.get(self.job_id, {}).get('status') == 'STOPPED':
            print(f"🛑 Stop signal detected for {self.job_id}. Halting...")
            control.should_training_stop = True

class AutoTrainEarlyStoppingCallback(TrainerCallback):
    def __init__(self, job_id, min_loss=0.5, patience=5):
        self.job_id = job_id
        self.min_loss = min_loss
        self.patience = patience
        # Logic cũ của bạn (theo dõi training loss)
        self.best_loss = float('inf')
        # Logic bổ sung (theo dõi eval loss để chống Overfit)
        self.best_eval_loss = float('inf')
        self.steps_without_improvement = 0

    def on_log(self, args, state, control, logs=None, **kwargs):
        if not logs: return

        # 1. LẤY GIÁ TRỊ LOSS (Ưu tiên eval_loss để chống Overfit, nếu không có thì dùng loss)
        eval_loss = logs.get("eval_loss")
        train_loss = logs.get("loss")

        # Quyết định chỉ số chính để theo dõi dừng sớm
        current_loss = eval_loss if eval_loss is not None else train_loss

        if current_loss is not None:
            # --- ĐIỀU KIỆN 1: DỪNG KHI ĐẠT MỤC TIÊU ---
            if current_loss < self.min_loss:
                msg = f"📉 Ngắt sớm: {'Eval' if eval_loss else 'Training'} Loss {current_loss:.4f} đã đạt mục tiêu (< {self.min_loss})."
                self._log_to_db(msg)
                control.should_training_stop = True
                return

            # --- ĐIỀU KIỆN 2: KIỂM TRA CẢI THIỆN (CHỐNG OVERFIT) ---
            # Sử dụng best_eval_loss nếu có eval, nếu không dùng best_loss
            target_best = self.best_eval_loss if eval_loss is not None else self.best_loss

            if current_loss < target_best:
                # Cập nhật mốc tốt nhất mới
                if eval_loss is not None: self.best_eval_loss = eval_loss
                else: self.best_loss = current_loss
                self.steps_without_improvement = 0
            else:
                self.steps_without_improvement += 1
                if self.steps_without_improvement >= self.patience:
                    msg = f"⏳ Tự động dừng: {'Eval' if eval_loss else 'Training'} Loss không giảm sau {self.patience} lần đánh giá."
                    if eval_loss: msg += " (Phát hiện dấu hiệu Overfit!)"
                    self._log_to_db(msg)
                    control.should_training_stop = True

    def _log_to_db(self, msg):
        print(msg)
        if self.job_id in jobs_db:
            if 'logs' not in jobs_db[self.job_id]: jobs_db[self.job_id]['logs'] = []
            jobs_db[self.job_id]['logs'].append(msg)


# ======================================================================
# 2. FORMAT PROMPT (Hỗ trợ trích xuất System Prompt từ dữ liệu)
# ======================================================================

# Fallback prompt nếu trong data không có role system
DEFAULT_SOCRATIC_PROMPT = (
    "Bạn là một trợ lý giáo dục chuyên nghiệp. Nhiệm vụ của bạn là hỗ trợ học sinh "
    "theo phương pháp Socratic: không đưa ra câu trả lời trực tiếp mà sử dụng "
    "các câu hỏi gợi mở để học sinh tự tìm ra đáp án trong mô hình Lớp học đảo ngược."
)

# def formatting_prompts_func(examples, column_mapping="text"):
#     texts = []
#     has_messages = "messages" in examples

#     if has_messages:
#         batch_size = len(examples["messages"])
#     else:
#         col = column_mapping if column_mapping in examples else next(iter(examples.keys()))
#         batch_size = len(examples[col])

#     for i in range(batch_size):
#         instruction, output = "", ""
#         system_content = "" # Khởi tạo để hứng system prompt từ mẫu

#         if has_messages:
#             msgs = examples["messages"][i]
#             for m in msgs:
#                 role = m.get("role")
#                 content = m.get("content", "")

#                 if role == "system":
#                     system_content = content
#                 elif role == "user":
#                     instruction = content
#                 elif role == "assistant":
#                     output = content
#         else:
#             instruction = examples.get(column_mapping, [""])[i]
#             output = examples.get("output", examples.get("answer", [""]))[i]

#         # Sử dụng system prompt từ mẫu, nếu không có thì dùng mặc định
#         final_system = system_content if system_content else DEFAULT_SOCRATIC_PROMPT

#         text = f"### System:\n{final_system}\n\n### Instruction:\n{instruction}\n\n### Response:\n{output} <|endoftext|>"
#         texts.append(text)
#     return {"text": texts}


def formatting_prompts_func(examples, tokenizer, col_map="messages", default_system=None):
    texts = []

    system_to_use = default_system if default_system else DEFAULT_SOCRATIC_PROMPT
    # Kiểm tra cột dữ liệu thực tế
    if col_map not in examples:
        # Nếu không tìm thấy cột map, thử dùng 'messages' hoặc cột đầu tiên
        actual_col = "messages" if "messages" in examples else next(iter(examples.keys()))
    else:
        actual_col = col_map


    # Lặp qua từng example trong batch
    for raw_content in examples[actual_col]:
        messages = raw_content

        # Nếu là string (từ CSV), parse JSON
        if isinstance(messages, str):
            try:
                import json
                messages = json.loads(messages)
            except:
                # Nếu không phải JSON, coi như 1 câu user (fallback)
                messages = [{"role": "user", "content": messages}]

        # Đảm bảo là list
        if not isinstance(messages, list):
            messages = [{"role": "user", "content": str(messages)}]

        # Kiểm tra xem mẫu đã có System Prompt chưa
        has_system = any(msg.get("role") == "system" for msg in messages if isinstance(msg, dict))

        # Nếu chưa có, chèn system prompt mặc định vào ĐẦU mảng
        if not has_system:
            messages.insert(0, {"role": "system", "content": system_to_use})

        # SỬ DỤNG TOKENIZER ĐỂ ÁP DỤNG CHAT TEMPLATE CỦA MÔ HÌNH
        try:
            formatted_text = tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=False
            )
            texts.append(formatted_text)
        except Exception as e:
            # Fallback nếu template lỗi
            fallback_text = ""
            for msg in messages:
                if isinstance(msg, dict):
                    role = msg.get("role", "user")
                    content = msg.get("content", "")
                    fallback_text += f"### {role.capitalize()}:\n{content}\n\n"
            texts.append(fallback_text)

    return {"text": texts}


import nltk
from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
from rouge_score import rouge_scorer

nltk.download('punkt', quiet=True)
nltk.download('punkt_tab', quiet=True)

def compute_ngram_metrics(expected: str, answer: str) -> dict:
    """Tính BLEU-1 và ROUGE-L giữa answer và expected reference."""
    if not expected or not answer:
        return {"bleu": 0.0, "rouge_l": 0.0}
    try:
        ref_tokens = nltk.word_tokenize(expected.lower())
        hyp_tokens = nltk.word_tokenize(answer.lower())
        smoothie = SmoothingFunction().method1
        bleu = round(sentence_bleu([ref_tokens], hyp_tokens, smoothing_function=smoothie), 4)
    except Exception:
        bleu = 0.0
    try:
        scorer = rouge_scorer.RougeScorer(['rougeL'], use_stemmer=False)
        rouge_l = round(scorer.score(expected, answer)['rougeL'].fmeasure, 4)
    except Exception:
        rouge_l = 0.0
    return {"bleu": bleu, "rouge_l": rouge_l}

print('✅ N-gram metrics (BLEU + ROUGE-L) sẵn sàng.')


def compute_question_detection_rate(assistant_turns: list[str]) -> float:
    """
    T?nh t? l? turn c?a assistant k?t th?c b?ng c?u h?i.
    Non-scoring metric ? ch? d?ng ?? ph?n t?ch xu h??ng.

    Logic: turn ???c coi l? c? c?u h?i n?u:
      - K?t th?c b?ng '?' (sau khi strip whitespace), HO?C
      - Ch?a '?' ? trong 100 k? t? cu?i (h? tr? c?u h?i kh?ng ? cu?i c?ng)

    Returns: float trong [0.0, 1.0]
    """
    if not assistant_turns:
        return 0.0

    count = 0
    for turn in assistant_turns:
        text = turn.strip()
        # Ki?m tra 100 k? t? cu?i ?? b?t c?u h?i embedded
        tail = text[-100:] if len(text) > 100 else text
        if '?' in tail:
            count += 1

    return round(count / len(assistant_turns), 4)

print('? Question Detection Rate s?n s?ng.')



# ======================================================================
# 3. AUTO EVALUATION — Claude LLM Judge (Multi-turn Socratic)
# ======================================================================

def _eval_log(job_id: str, msg: str):
    """Ghi log vào jobs_db[job_id]['logs'] và in ra console."""
    print(msg)
    if job_id in jobs_db:
        jobs_db[job_id].setdefault('logs', []).append(msg)

def _get_backend_url():
    url = _read_secret("BACKEND_URL")
    if url: return url.rstrip("/")
    return "http://localhost:3000"

BACKEND_URL = _get_backend_url()
print(f"[Config] BACKEND_URL = {BACKEND_URL}")

def _get_api_key():
    return _read_secret("ANTHROPIC_API_KEY")

def _compute_confidence(criteria: dict) -> dict:
    """
    Tính confidence proxy từ 1 lần judge duy nhất.
    Dựa trên độ đồng đều điểm trong từng nhóm:
    std thấp → judge nhất quán → confidence cao.
    """
    import statistics

    groups = {
        "A": ["A1", "A2", "A3"],
        "B": ["B1", "B2"],
        "C": ["C1", "C2", "C3"],
        "D": ["D1", "D2"],
    }

    group_confidences = {}
    for g, keys in groups.items():
        scores = [criteria.get(k, 0.0) for k in keys if k in criteria]
        if len(scores) < 2:
            group_confidences[g] = 1.0
            continue
        std = statistics.stdev(scores)
        conf = max(0.0, 1.0 - (std / 2.5))
        group_confidences[g] = round(conf, 3)

    overall_confidence = round(
        sum(group_confidences.values()) / len(group_confidences), 3
    )

    return {
        "overall": overall_confidence,
        "by_group": group_confidences,
        "is_low": overall_confidence < 0.6,
    }

# ── System prompt inject khi dataset không có role=system ────────────
DEFAULT_SOCRATIC_SYSTEM = (
    "Bạn là một gia sư thông minh, hỗ trợ học sinh THCS và THPT Việt Nam học tập "
    "theo phương pháp lớp học đảo ngược (Flipped Classroom).\n\n"
    "VAI TRÒ CỦA BẠN:\n"
    "- Không giảng lại lý thuyết từ đầu — học sinh đã tự học trước ở nhà.\n"
    "- Khi học sinh hỏi, hãy ưu tiên đặt câu hỏi gợi mở để kiểm tra mức độ hiểu "
    "và kích thích tư duy trước khi giải thích.\n"
    "- Hướng dẫn từng bước nhỏ, không đưa đáp án ngay — giúp học sinh tự tìm ra.\n"
    "- Nếu học sinh thực sự bí hoặc đã thử nhiều lần, mới giải thích chi tiết hơn.\n"
    "- Khen ngợi đúng lúc khi học sinh suy nghĩ đúng hướng.\n\n"
    "CÁCH GIAO TIẾP:\n"
    "- Tiếng Việt hoàn toàn.\n"
    "- Thân thiện như bạn bè nhưng đáng tin cậy.\n"
    "- Câu ngắn gọn, rõ ý. Tránh giải thích dài dòng khi chưa cần thiết."
)

BATCH_SIZE = 5  # số conversation mỗi lần gọi API

# ── System prompt: judge nhận ARRAY conversations ─────────────────────
SOCRATIC_JUDGE_SYSTEM_BATCH = """Bạn là chuyên gia đánh giá chất lượng hội thoại gia sư theo phương pháp Socratic.
Bạn sẽ nhận một DANH SÁCH các hội thoại được đánh số. Chấm điểm TỪNG hội thoại độc lập theo 9 tiêu chí (thang 0-5).
Ưu tiên ghi nhận những điểm tốt — chỉ trừ điểm khi lỗi rõ ràng và ảnh hưởng đến chất lượng học tập.
Lưu ý đặc biệt: A1 ≤ 1 (liên tục đưa đáp án trực tiếp mà không dẫn dắt) là vi phạm hard constraint và sẽ cap nhóm A.
CHỈ trả về JSON array, không có text khác.

TIÊU CHÍ:

A1 - Answer Withholding (Không đưa đáp án trực tiếp):
5: Không bao giờ đưa đáp án trong toàn hội thoại, mọi turn đều dẫn dắt.
4: Phần lớn giữ được; chỉ 1 turn hint khá rõ nhưng học sinh vẫn phải tự suy nghĩ thêm.
3: Có 1-2 turn cung cấp gợi ý gần như lộ đáp án, nhưng không đưa thẳng lời giải.
2: Có 1 turn đưa đáp án trực tiếp, nhưng phần còn lại của hội thoại vẫn duy trì phương pháp Socratic.
1: Đưa đáp án trực tiếp ở nhiều turn, dẫn dắt rất ít.
0: Đưa đáp án ngay từ đầu hoặc liên tục mà không cố gắng dẫn dắt.

A2 - Scaffolding Quality (Chất lượng câu hỏi dẫn dắt):
5: Câu hỏi cụ thể, bám sát nội dung, từng bước thu hẹp khoảng cách nhận thức.
4: Câu hỏi đúng hướng, đôi khi hơi chung nhưng học sinh vẫn có thể theo dõi được.
3: Câu hỏi phần lớn phù hợp nhưng đôi khi không kết nối tốt với câu trả lời trước hoặc quá rộng.
2: Câu hỏi lặp lại hoặc thiếu liên kết context; học sinh có thể bị bối rối ở một số turn.
1: Câu hỏi hầu như không bám sát nội dung hoặc context của học sinh.
0: Không có câu hỏi dẫn dắt nào, hoặc câu hỏi hoàn toàn lạc đề.

A3 - Adaptive Response (Phản ứng thích ứng):
5: Phản ứng phù hợp với tất cả kiểu input học sinh trong suốt hội thoại.
4: Phần lớn thích ứng tốt; chỉ 1 turn xử lý chưa tối ưu nhưng không gây cản trở học tập.
3: Đa số turn phản ứng phù hợp; có 2-3 turn xử lý hơi cứng hoặc chưa bắt đúng ý học sinh.
2: Có xu hướng phản ứng theo kịch bản; một số turn bỏ qua context rõ ràng của học sinh.
1: Thường xuyên không thích ứng; hầu hết các turn không phản ánh những gì học sinh vừa nói.
0: Bỏ qua hoàn toàn context của học sinh, trả lời theo kịch bản cố định.

B1 - Factual Accuracy (Độ chính xác kiến thức):
5: Không có lỗi kiến thức nào trong toàn hội thoại.
4: Có tối đa 1 lỗi nhỏ hoặc diễn đạt chưa chính xác hoàn toàn, không gây hiểu nhầm.
3: Có 1-2 chỗ không chính xác hoặc thiếu độ chính xác, nhưng kiến thức cốt lõi vẫn đúng.
2: Có lỗi kiến thức rõ ràng có thể khiến học sinh học sai, dù không phải toàn bộ hội thoại.
1: Nhiều lỗi kiến thức hoặc 1 lỗi nghiêm trọng ảnh hưởng đến hiểu biết của học sinh.
0: Sai kiến thức nghiêm trọng hoặc bịa đặt nội dung bài học.

B2 - Grade-level Appropriateness (Phù hợp trình độ cấp 2-3):
5: Ngôn ngữ thân thiện, ví dụ gần gũi, độ khó vừa đủ với THCS/THPT.
4: Phần lớn phù hợp; một vài thuật ngữ hơi chuyên sâu nhưng không cản trở hiểu.
3: Nhìn chung phù hợp; đôi khi quá học thuật hoặc quá đơn giản ở một số đoạn.
2: Có nhiều đoạn không phù hợp trình độ (quá khó hoặc quá dễ) nhưng vẫn có phần tốt.
1: Phần lớn hội thoại không phù hợp trình độ học sinh.
0: Hoàn toàn không phù hợp trình độ.

C1 - Robustness (Xử lý input mơ hồ/off-topic):
5: Luôn xử lý mượt — redirect về bài học tự nhiên hoặc phản hồi phù hợp context.
4: Hầu hết ổn; đôi khi bị lúng túng nhưng nhanh chóng lấy lại hướng.
3: Phần lớn xử lý được; bị confuse ở 1-2 turn nhưng không làm gián đoạn hội thoại đáng kể.
2: Xử lý không nhất quán; một số input đơn giản (như "ok", "xin chào") khiến mất hướng.
1: Thường xuyên mất hướng, khó lấy lại context sau các input mơ hồ.
0: Bịa context bài học từ system prompt không có thông tin, hoặc không phản hồi được gì có ích.

C2 - Conversational Coherence (Mạch lạc hội thoại):
5: Hội thoại mạch lạc xuyên suốt, mỗi turn kế thừa tốt câu trả lời trước.
4: Phần lớn mạch lạc; có 1-2 turn hơi rời rạc nhưng luồng tổng thể vẫn rõ ràng.
3: Mạch lạc ở mức khá; đôi khi lặp câu hỏi hoặc bỏ sót context nhưng không làm mất luồng chính.
2: Có dấu hiệu thiếu nhớ context; một số đoạn hội thoại cảm giác bị ngắt quãng.
1: Thường xuyên không nhớ context, hội thoại phần lớn rời rạc.
0: Mỗi turn hoàn toàn độc lập, không có sự kết nối.

C3 - Tone & Encouragement (Giọng điệu & khích lệ):
5: Tone nhất quán — ấm áp, khích lệ, không phán xét, phù hợp lứa tuổi.
4: Tone tốt; đôi khi hơi trang trọng hoặc ít khích lệ hơn mức lý tưởng.
3: Tone phần lớn tích cực; thỉnh thoảng hơi lạnh hoặc trung lập, nhưng không gây tác động tiêu cực.
2: Tone không nhất quán; có một số lúc khô khan hoặc hơi có hàm ý phán xét.
1: Tone khô khan xuyên suốt hoặc có câu từ phán xét rõ ràng khi học sinh mắc lỗi.
0: Không có yếu tố động viên nào, hoặc tone hoàn toàn không phù hợp lứa tuổi.

D1 - Hallucination Score:
5: Không có nội dung bịa đặt nào trong toàn hội thoại.
4: Có 1 chi tiết nhỏ không chắc chắn nhưng không gây hiểu nhầm hoặc ảnh hưởng đến học tập.
3: Có 1-2 thông tin không hoàn toàn chính xác nhưng mang tính ngoài lề, không ảnh hưởng nội dung chính.
2: Bịa 1 thông tin cụ thể (tên, số liệu, sự kiện) nhưng phần lớn nội dung vẫn đáng tin cậy.
1: Bịa nhiều thông tin cụ thể hoặc 1 thông tin sai quan trọng ảnh hưởng đến nội dung học.
0: Bịa context bài học, bịa câu trả lời của học sinh, hoặc sai fact nghiêm trọng.

Trả về JSON array, mỗi phần tử tương ứng với 1 hội thoại theo đúng thứ tự:
[
  {
    "conv_index": 0,
    "A1_answer_withholding": {"score": <0-5>, "reason": "<1-2 câu ngắn>"},
    "A2_scaffolding_quality": {"score": <0-5>, "reason": "<1-2 câu ngắn>"},
    "A3_adaptive_response":  {"score": <0-5>, "reason": "<1-2 câu ngắn>"},
    "B1_factual_accuracy":   {"score": <0-5>, "reason": "<1-2 câu ngắn>"},
    "B2_grade_level":        {"score": <0-5>, "reason": "<1-2 câu ngắn>"},
    "C1_robustness":         {"score": <0-5>, "reason": "<1-2 câu ngắn>"},
    "C2_coherence":          {"score": <0-5>, "reason": "<1-2 câu ngắn>"},
    "C3_tone":               {"score": <0-5>, "reason": "<1-2 câu ngắn>"},
    "D1_hallucination":      {"score": <0-5>, "reason": "<1-2 câu ngắn>"}
  },
  ...
]
CHỈ trả về JSON array, không có text khác."""

# ── Lookup: short key → full JSON key ─────────────────────────────────
_CRITERIA_KEYS = [
    "A1_answer_withholding", "A2_scaffolding_quality", "A3_adaptive_response",
    "B1_factual_accuracy", "B2_grade_level", "C1_robustness",
    "C2_coherence", "C3_tone", "D1_hallucination",
]
_SHORT_TO_FULL = {
    "A1": "A1_answer_withholding",
    "A2": "A2_scaffolding_quality",
    "A3": "A3_adaptive_response",
    "B1": "B1_factual_accuracy",
    "B2": "B2_grade_level",
    "C1": "C1_robustness",
    "C2": "C2_coherence",
    "C3": "C3_tone",
    "D1": "D1_hallucination",
}

def _zero_scores(reason: str) -> dict:
    return {k: {"score": 0, "reason": reason} for k in _CRITERIA_KEYS}

def _build_conv_text(idx: int, system_prompt: str, turns: list) -> str:
    lines = [f"=== HỘI THOẠI {idx} ===",
             f"[SYSTEM PROMPT]\n{system_prompt}",
             "[HỘI THOẠI]"]
    for t in turns:
        lines.append(f"Học sinh: {t['user']}\nGia sư: {t['model_response']}")
    return "\n\n".join(lines)

# ── Scoring constants ─────────────────────────────────────────────────
EVAL_STAGES = {
    "warmup":      {"pct": 3,  "label": "Khởi động GPU"},
    "replay_base": {"pct": 28, "label": "Replay Base model"},
    "replay_ft":   {"pct": 53, "label": "Replay FT model"},
    "replay":      {"pct": 53, "label": "Replay conversations"},
    "judge_base":  {"pct": 70, "label": "Chấm điểm Base model"},
    "judge_ft":    {"pct": 87, "label": "Chấm điểm FT model"},
    "judge":       {"pct": 87, "label": "Chấm điểm LLM judge"},
    "finalize":    {"pct": 98, "label": "Tổng hợp kết quả"},
}

DEFAULT_JUDGE_MODEL = "claude-sonnet-4-5-20251001"

def _score_latency(avg_ms: float) -> float:
    if avg_ms <= 2000:  return 5.0
    if avg_ms <= 4000:  return 4.0
    if avg_ms <= 7000:  return 3.0
    if avg_ms <= 12000: return 2.0
    return 1.0

def _compute_group_scores(criteria: dict) -> dict:
    a1 = criteria.get("A1", 0.0)
    a2 = criteria.get("A2", 0.0)
    a3 = criteria.get("A3", 0.0)
    b1 = criteria.get("B1", 0.0)
    b2 = criteria.get("B2", 0.0)
    c1 = criteria.get("C1", 0.0)
    c2 = criteria.get("C2", 0.0)
    c3 = criteria.get("C3", 0.0)
    d1 = criteria.get("D1", 0.0)
    d2 = criteria.get("D2", 0.0)

    group_a = a1 * 0.5 + a2 * 0.3 + a3 * 0.2
    if a1 <= 1.0:
        group_a = min(group_a, 2.0)

    group_b = b1 * 0.6 + b2 * 0.4
    group_c = c1 * 0.4 + c2 * 0.4 + c3 * 0.2
    group_d = d1 * 0.5 + d2 * 0.5

    overall = group_a * 0.40 + group_b * 0.25 + group_c * 0.25 + group_d * 0.10

    return {
        "group_a": round(group_a, 3),
        "group_b": round(group_b, 3),
        "group_c": round(group_c, 3),
        "group_d": round(group_d, 3),
        "overall": round(overall, 3),
        "a1_hard_constraint_triggered": (a1 <= 1.0),
    }

# ── Replay conversation với model ─────────────────────────────────────
def replay_conversation(conv: dict, model, tokenizer, max_new_tokens: int = 512) -> dict:
    messages = conv.get("messages", [])

    system_prompt = DEFAULT_SOCRATIC_SYSTEM
    for m in messages:
        if m.get("role") == "system":
            system_prompt = m.get("content", DEFAULT_SOCRATIC_SYSTEM)
            break

    user_turns = [m["content"] for m in messages if m.get("role") == "user"]
    if not user_turns:
        return {"system_prompt": system_prompt, "turns": [], "avg_latency_ms": 0.0, "assistant_turns": []}

    turns = []
    assistant_turns = []
    conversation_history = []

    infer_prompt_template = format_inference_prompt

    for user_content in user_turns:
        conversation_history.append({"role": "user", "content": user_content})

        try:
            messages_for_template = [{"role": "system", "content": system_prompt}] + conversation_history
            try:
                prompt = tokenizer.apply_chat_template(
                    messages_for_template,
                    tokenize=False,
                    add_generation_prompt=True,
                    enable_thinking=False,
                )
            except TypeError:
                prompt = tokenizer.apply_chat_template(
                    messages_for_template,
                    tokenize=False,
                    add_generation_prompt=True,
                )
        except Exception:
            prompt = f"### System:\n{system_prompt}\n\n### Instruction:\n{user_content}\n\n### Response:"

        inputs = tokenizer([prompt], return_tensors="pt").to("cuda")
        t0 = time.time()
        try:
            outputs = model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                use_cache=True,
                pad_token_id=tokenizer.eos_token_id,
                do_sample=False,
            )
            latency_ms = (time.time() - t0) * 1000
            response = tokenizer.batch_decode(outputs, skip_special_tokens=True)[0]
            if "### Response:" in response:
                response = response.split("### Response:")[-1].strip()
            elif tokenizer.eos_token and tokenizer.eos_token in response:
                response = response.split(tokenizer.eos_token)[0].strip()
            else:
                prompt_decoded = tokenizer.decode(inputs["input_ids"][0], skip_special_tokens=True)
                if response.startswith(prompt_decoded):
                    response = response[len(prompt_decoded):].strip()
        except Exception as e:
            latency_ms = (time.time() - t0) * 1000
            response = f"[ERROR: {e}]"

        turns.append({
            "user": user_content,
            "model_response": response,
            "latency_ms": round(latency_ms, 1),
        })
        assistant_turns.append(response)
        conversation_history.append({"role": "assistant", "content": response})

    avg_latency = round(sum(t["latency_ms"] for t in turns) / len(turns), 1) if turns else 0.0

    return {
        "system_prompt": system_prompt,
        "turns": turns,
        "replay_turns": [
            {
                "user": t["user"][:500],
                "model": t["model_response"][:800],
                "latency_ms": t["latency_ms"],
            }
            for t in turns
        ],
        "avg_latency_ms": avg_latency,
        "assistant_turns": assistant_turns,
    }

def _run_single_replay(job_id, eval_job_id, valid_convs, model, tokenizer,
                       stage_key: str, label: str) -> list:
    total = len(valid_convs)
    results = []
    _eval_log(job_id, f"[▶️] {label}: {total} conversations...")
    model.eval()
    FastLanguageModel.for_inference(model)
    for idx, conv in enumerate(valid_convs):
        _eval_log(job_id, f"  [{label} {idx+1}/{total}]")
        result = replay_conversation(conv, model, tokenizer)
        results.append(result)
        last_turn = result["turns"][-1] if result["turns"] else None
        _eval_progress(
            eval_job_id, stage_key, f"{idx+1}/{total}",
            current=idx+1, total=total,
            sample={
                "index": idx,
                "instruction": result["turns"][0]["user"] if result["turns"] else "",
                "ft_answer": last_turn["model_response"] if last_turn else None,
            }
        )
    return results

def _summarize(per_conv_results: list) -> dict:
    valid = [r for r in per_conv_results if r is not None]
    n = max(1, len(valid))

    def _avg(key_path):
        keys = key_path.split(".")
        vals = []
        for r in valid:
            v = r
            try:
                for k in keys: v = v[k]
                vals.append(float(v))
            except Exception: pass
        return round(sum(vals) / max(1, len(vals)), 3) if vals else 0.0

    criteria = {k: _avg(f"criteria_scores.{k}")
                for k in ["A1","A2","A3","B1","B2","C1","C2","C3","D1","D2"]}
    groups   = {k: _avg(f"group_scores.{k}")
                for k in ["group_a","group_b","group_c","group_d","overall"]}
    non_sc   = {
        "bleu":                    _avg("non_scoring.bleu"),
        "rouge_l":                 _avg("non_scoring.rouge_l"),
        "question_detection_rate": _avg("non_scoring.question_detection_rate"),
    }
    avg_lat  = _avg("avg_latency_ms")
    avg_conf = round(sum(r.get("confidence", {}).get("overall", 1.0) for r in valid) / n, 3)
    low_conf = sum(1 for r in valid if r.get("confidence", {}).get("is_low", False))

    return {
        "overall":              groups["overall"],
        "group_a":              groups["group_a"],
        "group_b":              groups["group_b"],
        "group_c":              groups["group_c"],
        "group_d":              groups["group_d"],
        "criteria":             criteria,
        "avg_latency_ms":       avg_lat,
        "non_scoring":          non_sc,
        "max_possible":         5,
        "avg_confidence":       avg_conf,
        "low_confidence_count": low_conf,
    }

# ── Gọi API cho 1 batch (tối đa BATCH_SIZE conversations) ─────────────
def _judge_batch(batch_replays: list, judge_model: str) -> list:
    """
    batch_replays: list of replay dict (system_prompt, turns, ...)
    Trả về list raw_scores dict theo đúng thứ tự.
    """
    api_key = _get_api_key()
    if not api_key:
        return [_zero_scores("no_api_key")] * len(batch_replays)

    parts = []
    for i, replay in enumerate(batch_replays):
        parts.append(_build_conv_text(i, replay["system_prompt"], replay["turns"]))
    batch_text = "\n\n".join(parts)

    try:
        client = anthropic.Anthropic(api_key=api_key)
        msg = client.messages.create(
            model=judge_model,
            max_tokens=1500 * len(batch_replays),  # scale theo batch size
            temperature=0,
            system=SOCRATIC_JUDGE_SYSTEM_BATCH,
            messages=[{"role": "user", "content": batch_text}],
        )
        reply = msg.content[0].text

        start = reply.find("[")
        end   = reply.rfind("]") + 1
        if start == -1 or end == 0:
            raise ValueError(f"Judge không trả về JSON array: {reply[:300]}")

        parsed = json.loads(reply[start:end])

        result = [None] * len(batch_replays)
        for item in parsed:
            idx = item.get("conv_index", None)
            if idx is not None and 0 <= idx < len(batch_replays):
                result[idx] = {k: item[k] for k in _CRITERIA_KEYS if k in item}

        # Fallback cho conv bị miss
        for i in range(len(batch_replays)):
            if result[i] is None:
                result[i] = _zero_scores("parse_miss")

        return result

    except Exception as e:
        print(f"[!] Batch judge error: {e}")
        return [_zero_scores(f"judge_error: {str(e)[:80]}")] * len(batch_replays)

# ── Hàm judge chính — thay thế _run_single_judge ──────────────────────
def _run_batch_judge(job_id, eval_job_id, valid_convs, replay_results,
                     judge_model: str, stage_key: str, label: str) -> list:
    """
    Drop-in replacement cho _run_single_judge.
    Trả về per_conv_results (list, có thể chứa None cho conv rỗng).
    """
    import statistics

    per_conv_results = []
    total = len(replay_results)
    _eval_log(job_id, f"[⚖️] {label}: {total} conversations | batch={BATCH_SIZE} | judge={judge_model}...")
    _eval_progress(eval_job_id, stage_key, "Đang gọi LLM judge (batch)...")

    # Zip cùng valid_convs để lấy original assistant turns cho ngram
    paired = list(zip(valid_convs, replay_results))
    chunks = [paired[i:i+BATCH_SIZE] for i in range(0, total, BATCH_SIZE)]

    for chunk_idx, chunk in enumerate(chunks):
        start_global = chunk_idx * BATCH_SIZE
        _eval_log(job_id, f"  [Batch {chunk_idx+1}/{len(chunks)}] conv {start_global+1}–{start_global+len(chunk)}")
        _eval_progress(eval_job_id, stage_key, f"Batch {chunk_idx+1}/{len(chunks)}")

        replays_in_chunk = [r for _, r in chunk]

        # Lọc conv None (replay thất bại) — không gửi API, trả None luôn
        valid_in_chunk = [(i, r) for i, r in enumerate(replays_in_chunk) if r is not None]
        batch_raw = [None] * len(chunk)

        if valid_in_chunk:
            idxs, replays = zip(*valid_in_chunk)
            scores_list = _judge_batch(list(replays), judge_model)
            for local_i, score in zip(idxs, scores_list):
                batch_raw[local_i] = score

        # Map từng conv trong chunk → per_conv_results
        for local_i, ((conv, replay), raw_scores) in enumerate(zip(chunk, batch_raw)):
            if replay is None or raw_scores is None:
                per_conv_results.append(None)
                continue

            criteria_scores = {
                short: float(raw_scores.get(full, {}).get("score", 0))
                for short, full in _SHORT_TO_FULL.items()
            }
            criteria_scores["D2"] = _score_latency(replay["avg_latency_ms"])

            group_scores = _compute_group_scores(criteria_scores)

            # Confidence: std của 9 criteria trong 1 lần chấm (D2 bỏ qua — objective)
            scores_vals = [criteria_scores[k] for k in _SHORT_TO_FULL]
            conf_std     = statistics.stdev(scores_vals) if len(scores_vals) >= 2 else 0.0
            conf_overall = round(max(0.0, 1.0 - conf_std / 2.5), 3)

            # Non-scoring metrics: BLEU, ROUGE-L, question detection rate
            orig_assistant  = [m["content"] for m in conv.get("messages", []) if m.get("role") == "assistant"]
            model_responses = replay.get("assistant_turns", [])
            ngram_list = [compute_ngram_metrics(ref, hyp)
                          for ref, hyp in zip(orig_assistant, model_responses)]
            ngram_avg = {
                "bleu":    round(sum(n["bleu"]    for n in ngram_list) / max(1, len(ngram_list)), 4),
                "rouge_l": round(sum(n["rouge_l"] for n in ngram_list) / max(1, len(ngram_list)), 4),
            } if ngram_list else {"bleu": 0.0, "rouge_l": 0.0}
            qdr = compute_question_detection_rate(model_responses)

            per_conv_results.append({
                "conv_index":      start_global + local_i,
                "num_turns":       len(replay["turns"]),
                "avg_latency_ms":  replay["avg_latency_ms"],
                "replay_turns":    replay.get("replay_turns", []),
                "criteria_scores": criteria_scores,
                "group_scores":    group_scores,
                "criteria_reasons": {
                    short: raw_scores.get(full, {}).get("reason", "")
                    for short, full in _SHORT_TO_FULL.items()
                },
                "confidence": {
                    "overall": conf_overall,
                    "std":     round(conf_std, 3),
                    "is_low":  conf_overall < 0.6,
                },
                "non_scoring": {
                    "bleu":                    ngram_avg["bleu"],
                    "rouge_l":                 ngram_avg["rouge_l"],
                    "question_detection_rate": qdr,
                },
            })

    valid_count = sum(1 for r in per_conv_results if r is not None)
    _eval_log(job_id, f"[✅] {label}: {valid_count}/{total} conversations chấm thành công.")
    return per_conv_results

def _compute_eval_flags(valid_results: list, summary: dict) -> list:
    import statistics
    flags = []
    total = len(valid_results)
    if total == 0:
        return flags

    constraint_count = sum(
        1 for r in valid_results
        if r.get("criteria_scores", {}).get("A1", 5.0) <= 1.0
    )
    if constraint_count / total > 0.3:
        flags.append("high_constraint_violation_rate")

    overalls = [r.get("group_scores", {}).get("overall", 0) for r in valid_results]
    if len(overalls) >= 2:
        std = statistics.stdev(overalls)
        if std > 1.2:
            flags.append("high_score_variance")

    avg_overall = sum(overalls) / len(overalls)
    if avg_overall < 1.8:
        flags.append("very_low_overall")

    confidences = [r.get("confidence", {}).get("overall", 1.0) for r in valid_results]
    avg_conf = sum(confidences) / len(confidences)
    if avg_conf < 0.6:
        flags.append("low_judge_confidence")

    if summary.get("avg_latency_ms", 0) > 10000:
        flags.append("high_latency")

    avg_a = summary.get("group_a", 0)
    avg_b = summary.get("group_b", 0)
    avg_c = summary.get("group_c", 0)
    if avg_a < 2.0 and (avg_b + avg_c) / 2 > 3.5:
        flags.append("socratic_underperforming")

    return flags

# ── Main eval function ────────────────────────────────────────────────
def run_auto_evaluation(job_id, eval_job_id, eval_file_path,
                        active_model, tokenizer, max_seq,
                        judge_model=DEFAULT_JUDGE_MODEL,
                        base_model=None, base_tokenizer=None,
                        base_model_repo=None, ft_model_repo=None):
    """
    Eval multi-turn conversation.
    - single mode: chỉ có active_model (FT)
    - paired mode: có thêm base_model → so sánh delta
    """
    # 1. Load dataset
    conversations = []
    ext = os.path.splitext(eval_file_path)[1].lower()
    try:
        if ext == ".jsonl":
            with open(eval_file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line:
                        try: conversations.append(json.loads(line))
                        except: pass
        else:
            with open(eval_file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            conversations = data if isinstance(data, list) else [data]
    except Exception as e:
        _eval_log(job_id, f"[Eval] Lỗi đọc file: {e}")
        return

    # Normalize
    valid_convs = []
    for c in conversations:
        msgs = c.get("messages", [])
        if any(m.get("role") == "user" for m in msgs):
            cleaned = []
            for m in msgs:
                if cleaned and cleaned[-1]["role"] == m["role"] == "assistant":
                    cleaned[-1]["content"] += "\n" + m["content"]
                else:
                    cleaned.append(m)
            valid_convs.append({**c, "messages": cleaned})

    if not valid_convs:
        _eval_log(job_id, "[Eval] Không có conversation hợp lệ.")
        return

    total = len(valid_convs)
    is_paired = base_model is not None
    eval_mode = "paired" if is_paired else "single"
    _eval_log(job_id, f"[📊] Mode: {eval_mode} | {total} conversations")

    # 2. Warmup FT model
    _eval_log(job_id, "[⚙️] Warming up GPU...")
    active_model.eval()
    FastLanguageModel.for_inference(active_model)
    try:
        _d = tokenizer(["Xin chào"], return_tensors="pt").to("cuda")
        active_model.generate(**_d, max_new_tokens=5, pad_token_id=tokenizer.eos_token_id)
    except Exception:
        pass
    _eval_progress(eval_job_id, "warmup", "GPU ready")

    # 3. Replay
    if is_paired:
        base_replay = _run_single_replay(
            job_id, eval_job_id, valid_convs,
            base_model, base_tokenizer,
            stage_key="replay_base", label="Replay Base"
        )
        ft_replay = _run_single_replay(
            job_id, eval_job_id, valid_convs,
            active_model, tokenizer,
            stage_key="replay_ft", label="Replay FT"
        )
    else:
        ft_replay = _run_single_replay(
            job_id, eval_job_id, valid_convs,
            active_model, tokenizer,
            stage_key="replay", label="Replay"
        )
        base_replay = None

    # 4. Judge — dùng _run_batch_judge (BATCH_SIZE conv/call)
    ft_per_conv = _run_batch_judge(
        job_id, eval_job_id, valid_convs, ft_replay,
        judge_model,
        stage_key="judge_ft" if is_paired else "judge",
        label="Judge FT" if is_paired else "Judge"
    )

    base_per_conv = None
    if is_paired:
        base_per_conv = _run_batch_judge(
            job_id, eval_job_id, valid_convs, base_replay,
            judge_model,
            stage_key="judge_base", label="Judge Base"
        )

    # 5. Summarize
    _eval_progress(eval_job_id, "finalize", "")
    ft_summary   = _summarize(ft_per_conv)
    base_summary = _summarize(base_per_conv) if is_paired else None

    # 6. Delta (paired only)
    delta = None
    if is_paired and base_summary:
        delta = {
            "overall":  round(ft_summary["overall"]  - base_summary["overall"],  3),
            "group_a":  round(ft_summary["group_a"]  - base_summary["group_a"],  3),
            "group_b":  round(ft_summary["group_b"]  - base_summary["group_b"],  3),
            "group_c":  round(ft_summary["group_c"]  - base_summary["group_c"],  3),
            "group_d":  round(ft_summary["group_d"]  - base_summary["group_d"],  3),
            "criteria": {
                k: round(ft_summary["criteria"][k] - base_summary["criteria"].get(k, 0), 3)
                for k in ft_summary["criteria"]
            },
            "avg_latency_ms": round(ft_summary["avg_latency_ms"] - base_summary["avg_latency_ms"], 1),
        }

    # 7. Flags (dựa trên FT)
    ft_valid = [r for r in ft_per_conv if r is not None]
    eval_flags = _compute_eval_flags(ft_valid, {
        "group_a": ft_summary["group_a"],
        "group_b": ft_summary["group_b"],
        "group_c": ft_summary["group_c"],
        "avg_latency_ms": ft_summary["avg_latency_ms"],
    })

    _eval_log(job_id, f"[✅] FT Overall: {ft_summary['overall']:.3f}/5")
    if is_paired:
        _eval_log(job_id, f"     Base Overall: {base_summary['overall']:.3f}/5")
        _eval_log(job_id, f"     Delta Overall: {delta['overall']:+.3f}")
    if eval_flags:
        _eval_log(job_id, f"[⚠️] Flags: {', '.join(eval_flags)}")

    eval_result = {
        "modelEvalId":        eval_job_id,
        "jobId":              job_id,
        "status":             "COMPLETED",
        "evalMode":           eval_mode,
        "ftModelRepo":        ft_model_repo,
        "baseModelRepo":      base_model_repo,
        "totalConversations": total,
        "validConversations": len(ft_valid),
        "judgeModel":         judge_model,
        "flags":              eval_flags,
        "perConvResults":     ft_per_conv,
        "summary":            ft_summary,
        "basePerConvResults": base_per_conv,
        "baseSummary":        base_summary,
        "delta":              delta,
        "startedAt":          time.strftime('%Y-%m-%dT%H:%M:%SZ'),
        "completedAt":        time.strftime('%Y-%m-%dT%H:%M:%SZ'),
    }
    jobs_db[job_id]['eval_result'] = eval_result
    _eval_log(job_id, "[💾] Kết quả eval đã lưu vào jobs_db.")


# ======================================================================
# 2. LÕI HUẤN LUYỆN (CORE TRAINING)
# ======================================================================
def background_train_task(job_id, config, filepath, hf_token):
    jobs_db[job_id]['status'] = 'TRAINING'
    local_job_dir = os.path.join(LOCAL_CHECKPOINT_BASE, job_id)
    hf_repo_id = config.get('hf_repo_id')

    try:
        if hf_token:
            print(f"🔑 Logging into Hugging Face for job {job_id}...")
            login(token=hf_token)

            if hf_repo_id and "/" not in hf_repo_id:
                api = HfApi()
                user_info = api.whoami(token=hf_token)
                username = user_info['name']
                hf_repo_id = f"{username}/{hf_repo_id}"
                print(f"📝 Updated repo ID to: {hf_repo_id}")

            if hf_repo_id and config.get('push_to_hub'):
                from huggingface_hub import create_repo
                try:
                    create_repo(repo_id=hf_repo_id, token=hf_token, repo_type="model", exist_ok=True)
                    print(f"✅ Repository {hf_repo_id} is ready.")
                except Exception as e:
                    print(f"⚠️ Warning creating repo: {e}")

        os.makedirs(local_job_dir, exist_ok=True)
        _release_gpu_memory()

        model, tokenizer = FastLanguageModel.from_pretrained(
            model_name=config['model_name'],
            max_seq_length=config['modelMaxLength'],
            load_in_4bit=True,
        )

        # Cấu hình Chat Template cho OpenAI format
        from unsloth import get_chat_template
        tokenizer = get_chat_template(
            tokenizer,
            chat_template = "chatml", # Hoặc dùng mapping tự động dựa trên model_name
            mapping = {"role" : "role", "content" : "content", "user" : "user", "assistant" : "assistant", "system" : "system"},
        )


        if getattr(tokenizer, "pad_token", None) is None:
            tokenizer.pad_token = tokenizer.eos_token
        tokenizer.padding_side = "right"

        model = FastLanguageModel.get_peft_model(
            model,
            r=config['r'],
            target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            lora_alpha=config['lora_alpha'],
            lora_dropout=config['lora_dropout'],
            bias="none",
            use_gradient_checkpointing="unsloth",
            random_state=config['random_state'],
        )

        col_map = config.get('column_mapping') or config.get('dataset_text_field') or 'text'
        sys_prompt = config.get('system_prompt')
        print(f"[Dataset] Using column mapping: {col_map}")
        if sys_prompt:
            print(f"[Dataset] Using custom system prompt: {sys_prompt[:50]}...")

        if filepath:
            ext = os.path.splitext(filepath)[1]
            dataset = load_dataset('json' if 'json' in ext else 'csv', data_files=filepath, split='train')
        elif config.get('dataset_hf_id'):
            dataset = load_dataset(config['dataset_hf_id'], split='train')
        else:
            raise ValueError("No dataset source provided.")

        # dataset = dataset.train_test_split(test_size=0.1, seed=42)


        # dataset_train = dataset["train"].map(lambda x: formatting_prompts_func(x, tokenizer), batched=True)
        # dataset_eval  = dataset["test"].map(lambda x: formatting_prompts_func(x, tokenizer), batched=True)

        # # Map dữ liệu
        # # dataset_train = dataset["train"].map(formatting_prompts_func, batched=True)
        # # dataset_eval  = dataset["test"].map(formatting_prompts_func, batched=True)

        # print("Text:",dataset_train[0]['text'])

        if len(dataset) == 0:
            raise ValueError("Dataset is empty. Please check your data file.")

        print(f"[Dataset] Loaded {len(dataset)} examples.")

        # Chỉ split nếu dataset đủ lớn
        if len(dataset) >= 10:
            dataset = dataset.train_test_split(test_size=0.1, seed=42)
            dataset_train = dataset["train"].map(lambda x: formatting_prompts_func(x, tokenizer, col_map, sys_prompt), batched=True)
            dataset_eval  = dataset["test"].map(lambda x: formatting_prompts_func(x, tokenizer, col_map, sys_prompt), batched=True)
        else:
            print("[Dataset] Warning: Dataset too small for splitting. Using entire dataset for training.")
            dataset_train = dataset.map(lambda x: formatting_prompts_func(x, tokenizer, col_map, sys_prompt), batched=True)
            dataset_eval  = None

        if len(dataset_train) > 0:
            print("Sample text:", dataset_train[0]['text'][:200], "...")
        else:
            print("[Dataset] Warning: dataset_train is empty after mapping.")

        resume_from = None
        resume_repo_id = config.get("checkpoint_hf_repo") or config.get("hf_repo_id") or hf_repo_id

        def _is_valid_checkpoint_dir(p):
            if not os.path.isdir(p):
                return False
            return (
                os.path.isfile(os.path.join(p, "trainer_state.json"))
                or os.path.isfile(os.path.join(p, "optimizer.pt"))
                or os.path.isfile(os.path.join(p, "scheduler.pt"))
                or os.path.isfile(os.path.join(p, "training_args.bin"))
            )

        def _pick_valid_checkpoint_under(p):
            if _is_valid_checkpoint_dir(p):
                return p
            try:
                children = [
                    os.path.join(p, d)
                    for d in os.listdir(p)
                    if os.path.isdir(os.path.join(p, d))
                ]
                for c in children:
                    if _is_valid_checkpoint_dir(c):
                        return c
            except Exception as e:
                print(f"[*] Could not scan checkpoint dir {p}: {e}")
            return None

        if resume_repo_id:
            try:
                snapshot_download(
                    repo_id=resume_repo_id,
                    local_dir=local_job_dir,
                    token=hf_token,
                    allow_patterns=[
                        "last-checkpoint",
                        "last-checkpoint/*",
                        "last-checkpoint/*/*",
                        "last-checkpoint/*/*/*",
                        "*.json",
                        "*.bin",
                        "*.pt",
                        "*.pth",
                        "*.safetensors",
                    ],
                    local_dir_use_symlinks=False,
                )
            except Exception as e:
                print(f"[*] snapshot_download failed: {e}")

            last_ckpt_path = os.path.join(local_job_dir, "last-checkpoint")

            if os.path.isdir(last_ckpt_path):
                resume_from = _pick_valid_checkpoint_under(last_ckpt_path)

            elif os.path.isfile(last_ckpt_path):
                try:
                    with open(last_ckpt_path, "r", encoding="utf-8") as f:
                        ref = (f.readline() or "").strip()
                    if ref:
                        candidate = os.path.join(local_job_dir, ref)
                        resume_from = _pick_valid_checkpoint_under(candidate)
                except Exception as e:
                    print(f"[*] Could not parse last-checkpoint file: {e}")

            if resume_from:
                print(f"[✅] Resuming from checkpoint: {resume_from}")
                if 'logs' not in jobs_db[job_id]:
                    jobs_db[job_id]['logs'] = []
                jobs_db[job_id]['logs'].append(f"Resuming from checkpoint: {resume_from}")
                # Fix: xóa best_model_checkpoint cũ trong trainer_state.json
                # để tránh Trainer load checkpoint từ job trước (absolute path không còn tồn tại)
                import glob as _glob
                for _state_file in _glob.glob(os.path.join(local_job_dir, '**/trainer_state.json'), recursive=True):
                    try:
                        with open(_state_file, 'r') as _f:
                            _state = json.load(_f)
                        if _state.get('best_model_checkpoint'):
                            _state['best_model_checkpoint'] = None
                            with open(_state_file, 'w') as _f:
                                json.dump(_state, _f, indent=2)
                            print(f"[*] Cleared stale best_model_checkpoint in {_state_file}")
                    except Exception as _e:
                        print(f"[*] Could not update trainer_state: {_e}")
            else:
                if config.get("checkpoint_source") == "hf" or config.get("checkpoint_hf_repo"):
                    raise ValueError(f"Can't find a valid checkpoint at {last_ckpt_path}")


          # Chuỗi đánh dấu bắt đầu câu trả lời của Bot trong Qwen (ChatML format)

        # response_template = "<|im_start|>assistant\n"

          # Khởi tạo Collator: Nó sẽ tìm chuỗi trên, và CHỈ tính loss từ đoạn đó trở đi
        # collator = DataCollatorForCompletionOnlyLM(
        #     response_template=response_template,
        #     tokenizer=tokenizer
        # )

        # 2.5. SFTTrainer Config (TỐI ƯU CHỐNG OVERFIT)
        trainer = SFTTrainer(
            model = model,
            processing_class = tokenizer,
            # tokenizer = tokenizer,
            train_dataset = dataset_train,
            eval_dataset = dataset_eval,      # Phải có tập này để tính Overfit
            # dataset_text_field = "text",

            # data_collator = collator,
            # max_seq_length = config['modelMaxLength'],

            # args = TrainingArguments(
            args = SFTConfig(
                max_length = config['modelMaxLength'],
                dataset_text_field = "text",
                packing = True,
                per_device_train_batch_size = config['batchSize'],
                gradient_accumulation_steps = config['gradient_accumulation_steps'],
                warmup_steps = config['warmup_steps'],
                num_train_epochs = config['epochs'],
                learning_rate = config['learningRate'],
                # Tự động chọn kiểu dữ liệu tối ưu dựa trên phần cứng GPU
                fp16 = not is_bfloat16_supported(),
                bf16 = is_bfloat16_supported(),
                logging_steps = 1,

                # --- CẤU HÌNH TÍNH TOÁN OVERFIT ---
                # eval_strategy = "steps", # Đánh giá định kỳ theo bước
                # eval_steps = 50,
                eval_strategy = "steps" if dataset_eval else "no", # Đánh giá định kỳ theo bước
                eval_steps = 50 if dataset_eval else None,# 50 bước "thi thử" 1 lần

                # --- CHIẾN LƯỢC CHỐNG "HỌC VẸT" ---
                # load_best_model_at_end = True, # Kết thúc sẽ lấy Model có kết quả thi tốt nhất
                # metric_for_best_model = "eval_loss",

                load_best_model_at_end = True if dataset_eval else False, # Kết thúc sẽ lấy Model có kết quả thi tốt nhất
                metric_for_best_model = "eval_loss" if dataset_eval else None,
                greater_is_better = False,     # Loss càng thấp càng tốt


                optim = config['optim'],
                weight_decay = config['weight_decay'],
                lr_scheduler_type = config['lr_scheduler_type'],
                seed = config['seed'],
                output_dir = local_job_dir,
                save_strategy = "steps",
                save_steps = 50,
                save_total_limit = 1,          # Tiết kiệm bộ nhớ Colab
                report_to = "none",
                push_to_hub = config.get('push_to_hub', False),
                hub_model_id = hf_repo_id,
                hub_token = hf_token,
                hub_strategy = "checkpoint",
            ),
            callbacks=[
                FlaskProgressCallback(job_id),
                EnhancedWatchdogCallback(job_id),
                AutoTrainEarlyStoppingCallback(job_id=job_id, min_loss=config.get('early_stopping_loss', 0.5), patience=50)
            ]
        )

        # 2.6. Bắt đầu huấn luyện (Tự động Resume nếu có checkpoint)
        trainer.train(resume_from_checkpoint = resume_from)

        if config.get('push_to_hub') and hf_repo_id:
            print(f"🎉 Training complete. Pushing final model to {hf_repo_id}...")
            model.push_to_hub(hf_repo_id, token=hf_token, commit_message="End of training push")
            tokenizer.push_to_hub(hf_repo_id, token=hf_token, commit_message="End of training push")
            jobs_db[job_id].update({'status': 'COMPLETED', 'progress': 100, 'final_path': f"hf://{hf_repo_id}"})
        else:
            jobs_db[job_id].update({'status': 'COMPLETED', 'progress': 100})

    except Exception as e:
        print(f"[❌] Error: {str(e)}")
        jobs_db[job_id].update({'status': 'ERROR', 'error': str(e)})
    finally:
        if os.path.exists(local_job_dir):
            shutil.rmtree(local_job_dir)

        if job_id in active_training_jobs:
            active_training_jobs.remove(job_id)
            print(f"[INFO] Job {job_id} finished. Worker free.")

        _release_gpu_memory()


def job_manager_thread():
    while True:
        if job_queue and len(active_training_jobs) < MAX_CONCURRENT_JOBS:
            job_id, config, file_path, hf_token = job_queue.popleft()

            if job_id in active_training_jobs:
                continue

            active_training_jobs.add(job_id)
            jobs_db[job_id] = {'status': 'PENDING', 'progress': 0, 'logs': []}
            print(f"[INFO] Bắt đầu Train Job {job_id}.")

            thread = threading.Thread(target=background_train_task, args=(job_id, config, file_path, hf_token))
            thread.start()

        time.sleep(3)


# Cell cập nhật job_manager_thread để đảm bảo tính đồng bộ
def job_manager_thread():
    while True:
        if job_queue and len(active_training_jobs) < MAX_CONCURRENT_JOBS:
            job_id, config, file_path, hf_token = job_queue.popleft()
            if job_id in active_training_jobs: continue
            active_training_jobs.add(job_id)
            jobs_db[job_id] = {'status': 'PENDING', 'progress': 0, 'logs': []}
            print(f"[INFO] Bắt đầu Train Job {job_id}.")
            thread = threading.Thread(target=background_train_task, args=(job_id, config, file_path, hf_token))
            thread.start()
        time.sleep(3)


# ======================================================================
# CELL NÀY ĐẶT TRƯỚC CELL SERVER (Cell 9 cuối)
# Định nghĩa helpers cho inference — chạy 1 lần trước khi start server
# ======================================================================

# ─────────────────────────────────────────────
# System Prompt — Flipped Classroom Tutor
# ─────────────────────────────────────────────
DEFAULT_SYSTEM_PROMPT = """Bạn là một gia sư thông minh, hỗ trợ học sinh THCS và THPT Việt Nam học tập theo phương pháp lớp học đảo ngược (Flipped Classroom).

VAI TRÒ CỦA BẠN:
- Không giảng lại lý thuyết từ đầu — học sinh đã tự học trước ở nhà.
- Khi học sinh hỏi, hãy ưu tiên đặt câu hỏi gợi mở để kiểm tra mức độ hiểu và kích thích tư duy trước khi giải thích.
- Hướng dẫn từng bước nhỏ, không đưa đáp án ngay — giúp học sinh tự tìm ra.
- Nếu học sinh thực sự bí hoặc đã thử nhiều lần, mới giải thích chi tiết hơn.
- Khen ngợi đúng lúc khi học sinh suy nghĩ đúng hướng.

CÁCH GIAO TIẾP:
- Tiếng Việt hoàn toàn.
- Thân thiện như bạn bè nhưng đáng tin cậy — không cợt nhả, không quá nghiêm túc.
- Câu ngắn gọn, rõ ý. Tránh giải thích dài dòng khi chưa cần thiết.
- Dùng ví dụ gần gũi với cuộc sống học sinh Việt Nam khi cần minh hoạ."""

# ─────────────────────────────────────────────
# Normalize history từ request body
# ─────────────────────────────────────────────
def normalize_history(raw_history, max_messages: int = 10) -> list:
    """
    Validate và làm sạch history từ frontend.
    - Chỉ giữ role "user" hoặc "assistant"
    - content phải là string không rỗng sau trim
    - Giữ tối đa max_messages message gần nhất
    """
    if not isinstance(raw_history, list):
        return []

    valid = []
    for item in raw_history:
        if not isinstance(item, dict):
            continue
        role = item.get("role", "")
        content = item.get("content", "")
        if role not in ("user", "assistant"):
            continue
        if not isinstance(content, str) or not content.strip():
            continue
        valid.append({"role": role, "content": content.strip()})

    # Giữ max_messages message gần nhất
    return valid[-max_messages:] if len(valid) > max_messages else valid


# ─────────────────────────────────────────────
# Format prompt đúng chat template của từng model
# Hỗ trợ history nhiều lượt
# enable_thinking=False → tắt <think> hoàn toàn
# ─────────────────────────────────────────────
def format_inference_prompt(tokenizer, system_prompt: str, history: list, user_input: str) -> str:
    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(history)
    messages.append({"role": "user", "content": user_input})

    try:
        # Qwen3 hỗ trợ enable_thinking — tắt để không sinh <think>
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
            enable_thinking=False,
        )
    except TypeError:
        # Model khác không hỗ trợ param này — fallback bình thường
        return tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True,
        )


# ─────────────────────────────────────────────
# Filter <think>...</think> khi stream
# ─────────────────────────────────────────────
def stream_without_thinking(streamer):
    """
    Accumulate buffer liên tục để tránh <think>/<think> bị split
    giữa 2 chunk (TextIteratorStreamer trả về từng token một).
    """
    OPEN_TAG  = "<think>"
    CLOSE_TAG = "</think>"

    buffer        = ""
    in_think      = False
    thinking_done = False

    for chunk in streamer:
        buffer += chunk

        if not in_think and not thinking_done:
            if OPEN_TAG in buffer:
                in_think = True
                buffer = buffer.split(OPEN_TAG, 1)[1]
            else:
                if len(buffer) > 10:
                    yield buffer[:-10]
                    buffer = buffer[-10:]
                continue

        if in_think:
            if CLOSE_TAG in buffer:
                in_think      = False
                thinking_done = True
                buffer = buffer.split(CLOSE_TAG, 1)[1]
            else:
                buffer = buffer[-9:] if len(buffer) > 9 else buffer
                continue

        if thinking_done and buffer:
            yield buffer
            buffer = ""

    if buffer and not in_think:
        yield buffer


print("✅ Inference helpers đã sẵn sàng.")



class ClusteringService:
    """
    Singleton giữ model + embedding cache dùng chung cho Visualize và Cluster.

    Cache lifecycle:
        visualize()           → _embed_cache   lưu conv_embeddings + raw data
        cluster()             → _cluster_cache lưu kết quả DBSCAN + KMeans
        filter_remove_noise() → đọc _cluster_cache, không ghi cache
        filter_deduplicate()  → đọc _cluster_cache, không ghi cache
        clear_cache()         → xóa toàn bộ cache
    """

    def __init__(self):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        print(f"[ClusteringService] Loading model on {self.device}...")
        self.model = SentenceTransformer("intfloat/multilingual-e5-base", device=self.device)
        self.model.max_seq_length = 512
        print("[ClusteringService] Model ready.")

        # ── Embedding cache (set bởi visualize, đọc bởi cluster) ──
        self._embed_cache: dict | None = None

        # ── Cluster cache (set bởi cluster, đọc bởi filter_*) ──
        self._cluster_cache: dict | None = None

    # ──────────────────────────────────────────────────────────────────────────
    # Cache helpers
    # ──────────────────────────────────────────────────────────────────────────

    # def _save_embed_cache(self, data: list[dict], conv_embeddings: np.ndarray,
    #                       conv_to_pair_indices: list[list[int]]):
    #     self._embed_cache = {
    #         "data":                 data,
    #         "conv_embeddings":      conv_embeddings,      # (N, 768) L2-normalized
    #         "conv_to_pair_indices": conv_to_pair_indices,
    #     }
    #     print(f"[EmbedCache] Saved {len(data)} conversations.")


    def _save_embed_cache(
        self,
        data: list[dict],
        conv_embeddings: np.ndarray,
        conv_to_pair_indices: list[list[int]],
        dataset_fingerprint: str,
    ):
        self._embed_cache = {
            "data":                 data,
            "conv_embeddings":      conv_embeddings,
            "conv_to_pair_indices": conv_to_pair_indices,
            "dataset_fingerprint":  dataset_fingerprint,
        }
        print(f"[EmbedCache] Saved {len(data)} conversations. fingerprint={dataset_fingerprint[:12]}")


    def _load_embed_cache(self) -> dict:
        if self._embed_cache is None:
            raise RuntimeError(
                "Chưa có embedding cache. Hãy gọi POST /api/cluster/visualize trước."
            )
        return self._embed_cache

    def _save_cluster_cache(self, data: list[dict], conv_embeddings: np.ndarray,
                             assignments: list[int], clean_indices: list[int],
                             final_labels: np.ndarray, centroids: np.ndarray,
                             similarities: np.ndarray):
        self._cluster_cache = {
            "data":             data,
            "conv_embeddings":  conv_embeddings,
            "assignments":      assignments,    # -1 = noise, 0..K-1 = cụm KMeans
            "clean_indices":    clean_indices,  # index trong data[] sau lọc noise
            "final_labels":     final_labels,   # nhãn KMeans, shape (len(clean_indices),)
            "centroids":        centroids,       # shape (K, dim), đã L2-normalize
            "similarities":     similarities,   # cosine sim mỗi điểm clean vs tâm cụm, shape (M,)
        }
        print(f"[ClusterCache] Saved. Total: {len(data)} | "
              f"Clean: {len(clean_indices)} | Noise: {len(data) - len(clean_indices)}")

    def _load_cluster_cache(self) -> dict:
        if self._cluster_cache is None:
            raise RuntimeError(
                "Chưa có cluster cache. Hãy gọi POST /api/cluster trước."
            )
        return self._cluster_cache

    def clear_cache(self):
        """Xóa toàn bộ cache (embed + cluster)."""
        self._embed_cache   = None
        self._cluster_cache = None
        print("[Cache] Cleared.")



    #########

    def _normalize_record_for_fingerprint(self, item: dict) -> dict:
        if "messages" in item and isinstance(item.get("messages"), list):
            return {
                "messages": [
                    {
                        "role": str(msg.get("role", "")),
                        "content": str(msg.get("content", "")),
                    }
                    for msg in item.get("messages", [])
                ]
            }

        return {
            "instruction": str(item.get("instruction", item.get("query", ""))),
            "input": str(item.get("input", item.get("context", ""))),
            "output": str(item.get("output", item.get("answer", item.get("response", "")))),
        }


    def _dataset_fingerprint(self, data: list[dict]) -> str:
        normalized = [self._normalize_record_for_fingerprint(item) for item in data]
        raw = json.dumps(normalized, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()


    def _parse_records_for_embedding(self, data: list[dict]):
        """
        Hỗ trợ cả:
        - OpenAI messages format
        - Alpaca format
        """
        all_pair_texts: list[str] = []
        conv_to_pair_indices: list[list[int]] = []
        count = 0

        for item in data:
            # OpenAI messages format
            if "messages" in item and isinstance(item.get("messages"), list):
                messages = item.get("messages", [])
                pairs: list[str] = []
                i = 0
                while i < len(messages):
                    msg = messages[i]
                    if msg.get("role") == "user":
                        user_content = str(msg.get("content", "")).strip()
                        if i + 1 < len(messages) and messages[i + 1].get("role") == "assistant":
                            assistant_content = str(messages[i + 1].get("content", "")).strip()
                            if user_content and assistant_content:
                                pairs.append(f"user:{user_content} assistant:{assistant_content}")
                            i += 2
                            continue
                    i += 1

                if pairs:
                    indices = []
                    for pair_text in pairs:
                        all_pair_texts.append(pair_text)
                        indices.append(count)
                        count += 1
                    conv_to_pair_indices.append(indices)
                else:
                    conv_to_pair_indices.append([])
                continue

            # Alpaca / lesson-like format
            instruction = str(item.get("instruction", item.get("query", ""))).strip()
            input_text = str(item.get("input", item.get("context", ""))).strip()
            output = str(item.get("output", item.get("answer", item.get("response", "")))).strip()

            user_text = "\n\n".join([part for part in [instruction, input_text] if part])
            if user_text and output:
                all_pair_texts.append(f"user:{user_text} assistant:{output}")
                conv_to_pair_indices.append([count])
                count += 1
            else:
                conv_to_pair_indices.append([])

        return all_pair_texts, conv_to_pair_indices


    def _ensure_embeddings(self, data: list[dict]) -> tuple[np.ndarray, str]:
        dataset_fingerprint = self._dataset_fingerprint(data)

        if (
            self._embed_cache is not None
            and self._embed_cache.get("dataset_fingerprint") == dataset_fingerprint
        ):
            print(f"[EmbedCache] Reused {len(data)} items. fingerprint={dataset_fingerprint[:12]}")
            return self._embed_cache["conv_embeddings"], dataset_fingerprint

        print("1. Parsing records for embedding...")
        all_pair_texts, conv_to_pair_indices = self._parse_records_for_embedding(data)
        if not all_pair_texts:
            raise ValueError("Không trích xuất được cặp nội dung hợp lệ để embedding.")

        print(f"2. Embedding {len(all_pair_texts)} pair-texts...")
        utt_embeddings = self._embed(all_pair_texts)

        print("3. Mean pooling + L2 normalize...")
        conv_embeddings = self._mean_pool_and_normalize(utt_embeddings, conv_to_pair_indices)

        self._save_embed_cache(
            data=data,
            conv_embeddings=conv_embeddings,
            conv_to_pair_indices=conv_to_pair_indices,
            dataset_fingerprint=dataset_fingerprint,
        )
        return conv_embeddings, dataset_fingerprint


    def _build_random_split(
        self,
        n: int,
        test_percentage: float,
        rng: np.random.Generator,
    ) -> tuple[list[int], list[int]]:
        if n <= 0:
            return [], []
        if n == 1:
            return [0], []

        safe_percentage = max(1.0, min(50.0, float(test_percentage)))
        test_count = int(round(n * (safe_percentage / 100.0)))
        test_count = max(1, min(n - 1, test_count))

        perm = rng.permutation(n).tolist()
        test_indices = sorted(perm[:test_count])
        train_indices = sorted(perm[test_count:])
        return train_indices, test_indices


    def _measure_cross_split_conflicts(
        self,
        embeddings: np.ndarray,
        train_indices: list[int],
        test_indices: list[int],
        threshold: float,
        preview_limit: int = 10,
    ) -> tuple[int, float, list[dict]]:
        if not train_indices or not test_indices:
            return 0, 0.0, []

        train_embs = embeddings[train_indices]  # (T, D)
        test_embs  = embeddings[test_indices]   # (S, D)

        # embeddings đã L2-normalize -> dot = cosine similarity
        sim_matrix = np.matmul(train_embs, test_embs.T)  # (T, S)

        max_similarity = float(sim_matrix.max()) if sim_matrix.size else 0.0
        conflict_positions = np.argwhere(sim_matrix > threshold)

        conflict_count = int(conflict_positions.shape[0])
        if conflict_count == 0:
            return 0, max_similarity, []

        preview = []
        scored_pairs = []
        for pos in conflict_positions:
            train_pos = int(pos[0])
            test_pos = int(pos[1])
            sim = float(sim_matrix[train_pos, test_pos])
            scored_pairs.append((sim, train_indices[train_pos], test_indices[test_pos]))

        scored_pairs.sort(key=lambda x: x[0], reverse=True)
        for sim, train_idx, test_idx in scored_pairs[:preview_limit]:
            preview.append({
                "trainIndex": train_idx,
                "testIndex": test_idx,
                "similarity": round(sim, 6),
            })

        return conflict_count, max_similarity, preview


    #########

    def safe_split(
        self,
        data: list[dict],
        test_percentage: float = 20,
        threshold: float = 0.85,
        max_attempts: int = 20,
        seed: int = 42,
    ) -> dict:
        """
        Sinh split train/test sao cho semantic conflict giữa 2 tập <= threshold.
        GPU service tự embed, tự đo similarity, tự auto re-split.

        Returns:
            {
                "resolved": bool,
                "attempts": int,
                "threshold": float,
                "trainIndices": list[int],
                "testIndices": list[int],
                "trainCount": int,
                "testCount": int,
                "conflictCount": int,
                "maxCrossSplitSimilarity": float,
                "datasetFingerprint": str,
                "conflictsPreview": list[dict]
            }
        """
        print("=== [SafeSplit] Bắt đầu ===")
        if not data:
            raise ValueError("data rỗng")

        conv_embeddings, dataset_fingerprint = self._ensure_embeddings(data)
        n = len(data)

        if n == 1:
            print("=== [SafeSplit] Chỉ có 1 mẫu, bỏ qua semantic split ===")
            return {
                "resolved": True,
                "attempts": 1,
                "threshold": float(threshold),
                "trainIndices": [0],
                "testIndices": [],
                "trainCount": 1,
                "testCount": 0,
                "conflictCount": 0,
                "maxCrossSplitSimilarity": 0.0,
                "datasetFingerprint": dataset_fingerprint,
                "conflictsPreview": [],
            }

        rng = np.random.default_rng(seed)
        safe_threshold = float(max(0.0, min(1.0, threshold)))
        safe_attempts = max(1, int(max_attempts))

        best_result = None

        for attempt in range(1, safe_attempts + 1):
            train_indices, test_indices = self._build_random_split(
                n=n,
                test_percentage=test_percentage,
                rng=rng,
            )

            conflict_count, max_similarity, conflicts_preview = self._measure_cross_split_conflicts(
                embeddings=conv_embeddings,
                train_indices=train_indices,
                test_indices=test_indices,
                threshold=safe_threshold,
                preview_limit=10,
            )

            current = {
                "resolved": conflict_count == 0,
                "attempts": attempt,
                "threshold": safe_threshold,
                "trainIndices": train_indices,
                "testIndices": test_indices,
                "trainCount": len(train_indices),
                "testCount": len(test_indices),
                "conflictCount": conflict_count,
                "maxCrossSplitSimilarity": round(max_similarity, 6),
                "datasetFingerprint": dataset_fingerprint,
                "conflictsPreview": conflicts_preview,
            }

            print(
                f"[SafeSplit] attempt={attempt} "
                f"train={len(train_indices)} test={len(test_indices)} "
                f"conflicts={conflict_count} max_sim={max_similarity:.4f}"
            )

            if best_result is None:
                best_result = current
            else:
                if current["conflictCount"] < best_result["conflictCount"]:
                    best_result = current
                elif (
                    current["conflictCount"] == best_result["conflictCount"]
                    and current["maxCrossSplitSimilarity"] < best_result["maxCrossSplitSimilarity"]
                ):
                    best_result = current

            if current["resolved"]:
                print("=== [SafeSplit] Hoàn tất: RESOLVED ===")
                return current

        print("=== [SafeSplit] Hoàn tất: UNRESOLVED ===")
        return best_result


    # ──────────────────────────────────────────────────────────────────────────
    # Embedding helpers
    # ──────────────────────────────────────────────────────────────────────────

    def _parse_conversations(self, data: list[dict]):
        """
        Mỗi cặp (user, assistant) liền kề → 1 text "user:{…} assistant:{…}" → 1 vector.
        Mean pool các vector trong conversation → 1 vector đại diện.
        Conversation không có cặp hợp lệ → vector zero → DBSCAN đánh noise.
        """
        all_pair_texts: list[str]        = []
        conv_to_pair_indices: list[list] = []
        count = 0

        for conv in data:
            messages = conv.get("messages", [])
            pairs: list[str] = []
            i = 0
            while i < len(messages):
                msg = messages[i]
                if msg.get("role") == "user":
                    user_content = msg.get("content", "").strip()
                    if (i + 1 < len(messages)
                            and messages[i + 1].get("role") == "assistant"):
                        assistant_content = messages[i + 1].get("content", "").strip()
                        if user_content and assistant_content:
                            pairs.append(
                                f"user:{user_content} assistant:{assistant_content}"
                            )
                        i += 2
                        continue
                i += 1

            if pairs:
                indices = []
                for pair_text in pairs:
                    all_pair_texts.append(pair_text)
                    indices.append(count)
                    count += 1
                conv_to_pair_indices.append(indices)
            else:
                conv_to_pair_indices.append([])

        return all_pair_texts, conv_to_pair_indices

    def _embed_long_text(self, text: str, chunk_size: int = 400,
                         overlap: int = 50) -> np.ndarray:
        """Late-chunking cho text dài: chunk có overlap → weighted mean pool."""
        words = text.split()
        if len(words) <= chunk_size:
            result = self.model.encode(
                ["query: " + text],
                normalize_embeddings=False,
                device=self.device,
            )
            return result[0].astype(np.float32)

        chunks, start = [], 0
        while start < len(words):
            end = min(start + chunk_size, len(words))
            chunks.append(" ".join(words[start:end]))
            if end == len(words):
                break
            start += chunk_size - overlap

        prefixed = ["query: " + c for c in chunks]
        chunk_embs = self.model.encode(
            prefixed, normalize_embeddings=False,
            batch_size=8, device=self.device,
        ).astype(np.float32)

        weights = np.array([len(c.split()) for c in chunks], dtype=np.float32)
        weights /= weights.sum()
        return np.sum(chunk_embs * weights[:, np.newaxis], axis=0)

    def _embed(self, utterances: list[str]) -> np.ndarray:
        """Batch encode text ngắn + late-chunking cho text dài."""
        TOKEN_LIMIT_WORDS = 350
        dim = self.model.get_sentence_embedding_dimension()
        embeddings = np.zeros((len(utterances), dim), dtype=np.float32)

        short_idx = [i for i, u in enumerate(utterances)
                     if len(u.split()) <= TOKEN_LIMIT_WORDS]
        long_idx  = [i for i, u in enumerate(utterances)
                     if len(u.split()) >  TOKEN_LIMIT_WORDS]

        if short_idx:
            pairs = [("query: " + utterances[i], i)
                     for i in short_idx if utterances[i].strip()]
            if pairs:
                texts_list, orig_indices = zip(*pairs)
                vecs = self.model.encode(
                    list(texts_list),
                    show_progress_bar=True,
                    normalize_embeddings=False,
                    batch_size=32,
                    device=self.device,
                ).astype(np.float32)
                for pos, orig_i in enumerate(orig_indices):
                    embeddings[orig_i] = vecs[pos]

        if long_idx:
            print(f"   -> {len(long_idx)} text dài → late chunking...")
            for orig_i in long_idx:
                embeddings[orig_i] = self._embed_long_text(utterances[orig_i])

        return embeddings

    def _mean_pool_and_normalize(self, utt_embeddings: np.ndarray,
                                  conv_to_utt_indices: list) -> np.ndarray:
        dim = utt_embeddings.shape[1]
        conv_embs = []
        for indices in conv_to_utt_indices:
            if not indices:
                conv_embs.append(np.zeros(dim, dtype=np.float32))
            else:
                conv_embs.append(np.mean(utt_embeddings[indices], axis=0))
        conv_embs = np.array(conv_embs, dtype=np.float32)
        norms = np.linalg.norm(conv_embs, axis=1, keepdims=True)
        norms[norms == 0] = 1e-10
        return conv_embs / norms

    # ──────────────────────────────────────────────────────────────────────────
    # Output helpers
    # ──────────────────────────────────────────────────────────────────────────

    def _normalize_centroids(self, centroids: np.ndarray) -> np.ndarray:
        c = centroids.astype(np.float32)
        norms = np.linalg.norm(c, axis=1, keepdims=True)
        norms[norms == 0] = 1e-10
        return c / norms

    def _compute_similarities(self, conv_embeddings: np.ndarray,
                               clean_indices: list[int],
                               final_labels: np.ndarray,
                               centroids: np.ndarray) -> np.ndarray:
        """
        Tính cosine similarity giữa mỗi điểm clean và tâm cụm được gán.

        conv_embeddings và centroids đều đã L2-normalize
        → dot product = cosine similarity.

        Returns:
            similarities: np.ndarray shape (M,), dtype float32
                          M = len(clean_indices)
        """
        clean_embs         = conv_embeddings[clean_indices]   # (M, dim)
        assigned_centroids = centroids[final_labels]          # (M, dim)
        return np.sum(clean_embs * assigned_centroids, axis=1).astype(np.float32)

    def _make_label(self, cluster_id: int) -> str:
        return f"Cụm {cluster_id}"

    def _build_output(self, data: list, assignments: list) -> dict:
        result_data = [{**item, "cluster": assignments[i]}
                       for i, item in enumerate(data)]
        count_map: dict = defaultdict(int)
        for cid in assignments:
            count_map[cid] += 1
        groups = [
            {
                "groupId": cid,
                "count":   count_map[cid],
                "label":   "Nhiễu" if cid == -1 else self._make_label(cid),
            }
            for cid in sorted(count_map.keys())
        ]
        return {"data": result_data, "assignments": assignments, "groups": groups}

    # ──────────────────────────────────────────────────────────────────────────
    # Step 3 — Visualize
    # ──────────────────────────────────────────────────────────────────────────


    # ─────────────────────────────────────────────────────────────────────────────
    # Private helpers
    # ─────────────────────────────────────────────────────────────────────────────

    def _compute_elbow(self, embeddings: np.ndarray, max_k: int) -> list[dict]:
        """
        Tính WCSS (Within-Cluster Sum of Squares) cho k = 1..max_k.

        Args:
            embeddings: L2-normalized numpy array, shape (N, D).
            max_k:      Giá trị k lớn nhất cần thử.

        Returns:
            List of {"k": int, "wcss": float}, sorted by k ascending.
        """
        limit_k = min(max_k, len(embeddings))
        results = []
        for k in range(1, limit_k + 1):
            km = KMeans(n_clusters=k, random_state=42, n_init="auto")
            km.fit(embeddings)
            results.append({"k": k, "wcss": float(km.inertia_)})
        return results


    def _compute_silhouette(
        self, embeddings: np.ndarray, max_k: int
    ) -> list[dict]:
        """
        Tính Silhouette Score cho k = 2..max_k.
        Silhouette không xác định với k=1 nên bắt đầu từ k=2.

        Args:
            embeddings: L2-normalized numpy array, shape (N, D).
            max_k:      Giá trị k lớn nhất cần thử.

        Returns:
            List of {"k": int, "silhouette": float}, sorted by k ascending.
            Giá trị nằm trong [-1, 1]; càng cao càng tốt.
        """
        # Cần ít nhất 2 cluster và 3 điểm (sklearn yêu cầu n_samples > n_clusters)
        limit_k = min(max_k, len(embeddings) - 1)
        if limit_k < 2:
            return []

        results = []
        for k in range(2, limit_k + 1):
            km = KMeans(n_clusters=k, random_state=42, n_init="auto")
            labels = km.fit_predict(embeddings)
            # Chỉ tính khi có ít nhất 2 cluster thực sự xuất hiện
            if len(set(labels)) < 2:
                continue
            score = silhouette_score(embeddings, labels, metric="euclidean")
            results.append({"k": k, "silhouette": float(score)})
        return results


    # ─────────────────────────────────────────────────────────────────────────────
    # Public method
    # ─────────────────────────────────────────────────────────────────────────────

    def visualize(
        self,
        data: list[dict],
        max_k: int,
        eps: float,
        min_samples: int,
    ) -> dict:
        """
        Embed toàn bộ data, lưu conv_embeddings vào _embed_cache,
        rồi tính Elbow + Silhouette + K-Distance dựa trên tập đã lọc noise.

        Args:
            data:        Danh sách conversation dict.
            max_k:       Số cluster tối đa cần khảo sát.
            eps:         Tham số epsilon cho DBSCAN (ngưỡng khoảng cách).
            min_samples: Số điểm tối thiểu trong vùng lân cận cho DBSCAN.

        Returns:
            {
                "elbow":      [{"k": int, "wcss": float}, ...],
                "silhouette": [{"k": int, "silhouette": float}, ...],
                "kDistance":  [{"rank": int, "distance": float}, ...],
                "pointCount": int,   # số điểm sạch (sau khi lọc noise)
                "noiseCount": int,   # số điểm bị DBSCAN đánh dấu noise
            }
        """
        print("=== [Visualize] Bắt đầu ===")

        # # ── 1. Parse & embed ──────────────────────────────────────────────────
        # print("1. Parsing conversations...")
        # all_pair_texts, conv_to_pair_indices = self._parse_conversations(data)
        # if not all_pair_texts:
        #     raise ValueError(
        #         "Không trích xuất được cặp (user, assistant) nào từ data."
        #     )

        # print(f"2. Embedding {len(all_pair_texts)} pair-texts...")
        # utt_embeddings = self._embed(all_pair_texts)

        # print("3. Mean pooling + L2 normalize...")
        # conv_embeddings = self._mean_pool_and_normalize(
        #     utt_embeddings, conv_to_pair_indices
        # )  # shape (N, 768)

        # # ── 2. Lưu embedding cache để cluster() tái sử dụng ──────────────────
        # self._save_embed_cache(data, conv_embeddings, conv_to_pair_indices)

        # # ── 3. DBSCAN lọc noise ───────────────────────────────────────────────
        # print(f"4. DBSCAN noise filter (eps={eps}, min_samples={min_samples})...")
        # dbscan = DBSCAN(eps=eps, min_samples=min_samples, metric="cosine")
        # db_labels = dbscan.fit_predict(conv_embeddings)

        conv_embeddings, _dataset_fingerprint = self._ensure_embeddings(data)

        print(f"4. DBSCAN noise filter (eps={eps}, min_samples={min_samples})...")
        dbscan = DBSCAN(eps=eps, min_samples=min_samples, metric="cosine")
        db_labels = dbscan.fit_predict(conv_embeddings)

        noise_mask  = db_labels == -1
        noise_count = int(noise_mask.sum())
        clean_embs  = conv_embeddings[~noise_mask]
        point_count = len(clean_embs)
        print(f"   -> Noise: {noise_count} | Clean: {point_count}")

        if point_count == 0:
            raise ValueError(
                "Toàn bộ dữ liệu bị DBSCAN đánh nhãn là noise. "
                "Hãy thử tăng eps hoặc giảm min_samples."
            )

        # ── 4. Elbow Method ───────────────────────────────────────────────────
        print(f"5. Elbow Method (max_k={max_k})...")
        elbow_data = self._compute_elbow(clean_embs, max_k)

        # ── 5. Silhouette Score ───────────────────────────────────────────────
        print(f"6. Silhouette Score (max_k={max_k})...")
        silhouette_data = self._compute_silhouette(clean_embs, max_k)

        # ── 6. K-Distance Graph ───────────────────────────────────────────────
        print(f"7. K-Distance Graph (k={min_samples})...")
        n_neighbors = min(min_samples, point_count - 1)
        k_distance_data = []
        if n_neighbors >= 1:
            nbrs = NearestNeighbors(n_neighbors=n_neighbors, metric="cosine")
            nbrs.fit(clean_embs)
            dists, _ = nbrs.kneighbors(clean_embs)
            kth = np.sort(dists[:, -1])[::-1]
            k_distance_data = [
                {"rank": int(i + 1), "distance": float(d)}
                for i, d in enumerate(kth)
            ]

        print("=== [Visualize] Hoàn tất ===")
        return {
            "elbow":      elbow_data,
            "silhouette": silhouette_data,
            "kDistance":  k_distance_data,
            "pointCount": point_count,
            "noiseCount": noise_count,
        }

    # ──────────────────────────────────────────────────────────────────────────
    # Step 4 — Cluster  (DBSCAN + KMeans, lưu _cluster_cache)
    # API: POST /api/cluster
    # ──────────────────────────────────────────────────────────────────────────

    def cluster(self, k: int, eps: float, min_samples: int) -> dict:
        """
        Đọc conv_embeddings từ _embed_cache (không embed lại),
        chạy DBSCAN lọc noise rồi KMeans phân cụm,
        lưu toàn bộ kết quả vào _cluster_cache để filter_* tái sử dụng.

        Phải gọi visualize() trước.

        Returns:
            {
                "data":        list[dict],  # toàn bộ data kèm cluster id
                "assignments": list[int],   # -1 = noise, 0..K-1 = cụm KMeans
                "groups":      list[dict],  # [{groupId, count, label}, ...]
                "clusterStats":    list[dict],  # [{clusterId, avgSimilarity, count}, ...]
                "avgSimilarity":   float,       # trung bình toàn bộ tập clean
            }
        """
        print("=== [Cluster] Bắt đầu ===")
        cache = self._load_embed_cache()
        data            = cache["data"]
        conv_embeddings = cache["conv_embeddings"]

        # ── 1. DBSCAN lọc noise ───────────────────────────────────────────────
        print(f"1. DBSCAN (eps={eps}, min_samples={min_samples})...")
        dbscan = DBSCAN(eps=eps, min_samples=min_samples, metric="cosine")
        dbscan_labels = dbscan.fit_predict(conv_embeddings)

        clean_indices = [i for i, lbl in enumerate(dbscan_labels) if lbl != -1]
        noise_count   = len(dbscan_labels) - len(clean_indices)
        print(f"   -> Nhiễu: {noise_count} | Sạch: {len(clean_indices)}")

        if not clean_indices:
            raise ValueError(
                "Toàn bộ dữ liệu bị DBSCAN đánh nhãn là noise. "
                "Hãy thử tăng eps hoặc giảm min_samples."
            )

        # ── 2. KMeans phân cụm trên tập clean ────────────────────────────────
        num_clusters = max(1, min(k, len(clean_indices)))
        print(f"2. KMeans (K={num_clusters}) trên {len(clean_indices)} điểm sạch...")
        kmeans = KMeans(n_clusters=num_clusters, random_state=42, n_init="auto")
        final_labels = kmeans.fit_predict(conv_embeddings[clean_indices])
        centroids    = self._normalize_centroids(kmeans.cluster_centers_)

        # ── 3. Ghép nhãn KMeans vào assignments (giữ -1 cho noise) ──────────
        assignments = [-1] * len(data)
        for pos, orig_idx in enumerate(clean_indices):
            assignments[orig_idx] = int(final_labels[pos])

        # ── 4. Tính cosine similarity mỗi điểm clean vs tâm cụm ──────────────
        final_labels_arr = np.array(final_labels, dtype=np.int32)
        similarities = self._compute_similarities(
            conv_embeddings, clean_indices, final_labels_arr, centroids
        )

        # ── 5. Tổng hợp avg similarity theo từng cụm + toàn bộ tập clean ─────
        cluster_sim_sum   = defaultdict(float)
        cluster_sim_count = defaultdict(int)
        for pos, cid in enumerate(final_labels_arr):
            cluster_sim_sum[int(cid)]   += float(similarities[pos])
            cluster_sim_count[int(cid)] += 1

        cluster_stats = [
            {
                "clusterId":     cid,
                "avgSimilarity": round(cluster_sim_sum[cid] / cluster_sim_count[cid], 4),
                "count":         cluster_sim_count[cid],
            }
            for cid in sorted(cluster_sim_sum.keys())
        ]
        overall_avg_similarity = round(float(similarities.mean()), 4)

        self._save_cluster_cache(
            data=data,
            conv_embeddings=conv_embeddings,
            assignments=assignments,
            clean_indices=clean_indices,
            final_labels=final_labels_arr,
            centroids=centroids,
            similarities=similarities,
        )

        print("=== [Cluster] Hoàn tất ===")
        output = self._build_output(data, assignments)
        output["clusterStats"]  = cluster_stats
        output["avgSimilarity"] = overall_avg_similarity
        return output

    # ──────────────────────────────────────────────────────────────────────────
    # Step 5a — Filter: Remove Noise
    # API: POST /api/cluster/filter/remove-noise
    # ──────────────────────────────────────────────────────────────────────────

    def filter_remove_noise(self) -> dict:
        """
        Đọc _cluster_cache, loại bỏ tất cả điểm có cluster == -1 (noise DBSCAN).
        Trả về phần còn lại với nhãn cụm KMeans nguyên vẹn.

        Phải gọi cluster() trước.
        Hoạt động độc lập với filter_deduplicate().

        Returns:
            {
                "data":         list[dict],
                "assignments":  list[int],   # chỉ còn 0..K-1
                "groups":       list[dict],
                "removedCount": int,          # số điểm noise bị loại
                "keptCount":    int           # số điểm còn lại
            }
        """
        print("=== [FilterRemoveNoise] Bắt đầu ===")
        cache       = self._load_cluster_cache()
        data        = cache["data"]
        assignments = cache["assignments"]

        kept_data, kept_assignments = [], []
        removed_count = 0

        for i, item in enumerate(data):
            if assignments[i] == -1:
                removed_count += 1
            else:
                kept_data.append(item)
                kept_assignments.append(assignments[i])

        print(f"   -> Loại bỏ noise: {removed_count} | Giữ lại: {len(kept_data)}")
        print("=== [FilterRemoveNoise] Hoàn tất ===")

        output = self._build_output(kept_data, kept_assignments)
        output["removedCount"] = removed_count
        output["keptCount"]    = len(kept_data)
        return output

    # ──────────────────────────────────────────────────────────────────────────
    # Step 5b — Filter: Deduplicate
    # API: POST /api/cluster/filter/deduplicate
    # ──────────────────────────────────────────────────────────────────────────

    def filter_deduplicate(self, threshold: float = 0.9) -> dict:
        """
        Đọc _cluster_cache, loại bỏ các điểm có cosine similarity với tâm
        cụm > threshold (quá giống nhau / trùng lặp). Điểm noise bỏ qua.
        Luôn giữ lại đúng 1 điểm gần tâm nhất của mỗi cụm.

        Phải gọi cluster() trước.
        Hoạt động độc lập với filter_remove_noise().

        Cosine similarity = dot(e, c) vì conv_embeddings và centroids
        đều đã L2-normalized → cosine_distance = 1 - similarity.

        Returns:
            {
                "data":         list[dict],
                "assignments":  list[int],
                "groups":       list[dict],
                "removedCount": int,          # số điểm bị loại do quá gần tâm
                "keptCount":    int           # số điểm còn lại
            }
        """
        print(f"=== [FilterDeduplicate] threshold={threshold} ===")
        cache           = self._load_cluster_cache()
        data            = cache["data"]
        conv_embeddings = cache["conv_embeddings"]
        assignments     = cache["assignments"]
        clean_indices   = cache["clean_indices"]
        final_labels    = cache["final_labels"]
        centroids       = cache["centroids"]

        # ── Đọc similarities từ cache (đã tính sẵn bởi cluster()) ────────────
        similarities = cache["similarities"]

        # ── Điểm gần tâm nhất mỗi cụm → bắt buộc giữ lại ────────────────────
        centroid_reps: dict = {}
        for cid in np.unique(final_labels):
            pos_in_cluster = np.where(final_labels == cid)[0]
            best_pos       = pos_in_cluster[np.argmax(similarities[pos_in_cluster])]
            centroid_reps[int(cid)] = best_pos

        protected = set(centroid_reps.values())

        # ── Index trong data[] cần loại (sim > threshold, không phải rep) ─────
        too_close = {
            clean_indices[pos]
            for pos, sim in enumerate(similarities)
            if sim > threshold and pos not in protected
        }

        kept_data, kept_assignments = [], []
        for i, item in enumerate(data):
            if assignments[i] == -1:   # bỏ qua noise
                continue
            if i in too_close:         # bỏ qua điểm trùng lặp
                continue
            kept_data.append(item)
            kept_assignments.append(assignments[i])

        removed_count = len(too_close)
        print(f"   -> Loại bỏ (quá gần tâm): {removed_count} | Giữ lại: {len(kept_data)}")
        print("=== [FilterDeduplicate] Hoàn tất ===")

        output = self._build_output(kept_data, kept_assignments)
        output["removedCount"] = removed_count
        output["keptCount"]    = len(kept_data)
        return output


# ── eval_jobs_db: lưu trạng thái eval độc lập với jobs_db (train) ────────────
eval_jobs_db = {}


def _eval_progress(eval_job_id, stage: str, detail: str = "", current: int = 0, total: int = 0, sample: dict = None):
    """C?p nh?t progress structured v?o eval_jobs_db."""
    if eval_job_id not in eval_jobs_db:
        return

    stage_info = EVAL_STAGES.get(stage, {"pct": 0, "label": stage})
    pct = stage_info["pct"]

    # T?nh progress n?i suy cho c?c stage c? sub-steps (replay v? judge)
    if total > 0 and stage in ("replay", "judge"):
        stages = list(EVAL_STAGES.keys())
        idx = stages.index(stage) if stage in stages else -1
        if idx > 0:
            start_pct = EVAL_STAGES[stages[idx - 1]]["pct"]
            end_pct = stage_info["pct"]
            pct = int(start_pct + (end_pct - start_pct) * current / total)

    update = {
        "progress":      pct,
        "stage":         stage,
        "stage_label":   stage_info["label"],
        "stage_detail":  detail,
        "stage_current": current,
        "stage_total":   total,
    }
    if sample is not None:
        update["current_sample"] = sample

    eval_jobs_db[eval_job_id].update(update)
def background_eval_task(eval_job_id: str, job_id: str, hf_repo_id: str,
                          hf_token: str, eval_file_path: str, model_max_length: int,
                          judge_model: str = DEFAULT_JUDGE_MODEL,
                          base_hf_repo: str = ""):
    """
    Chạy đánh giá độc lập — KHÔNG phụ thuộc vào train job.
    Load model từ HuggingFace Hub (hf_repo_id) vào GPU,
    chạy run_auto_evaluation(), lưu kết quả vào eval_jobs_db.
    """
    eval_jobs_db[eval_job_id]['status'] = 'RUNNING'

    def _log(msg):
        print(msg)
        if eval_job_id in eval_jobs_db:
            eval_jobs_db[eval_job_id].setdefault('logs', []).append(msg)

    model = None
    tokenizer = None

    try:
        _release_gpu_memory()

        _log(f"[🔄] Loading model từ HF Hub: {hf_repo_id}...")
        model, tokenizer = FastLanguageModel.from_pretrained(
            model_name=hf_repo_id,
            max_seq_length=max(model_max_length, 4096),  # eval cần context dài hơn train
            load_in_4bit=True,
            token=hf_token or None,
        )
        if getattr(tokenizer, "pad_token", None) is None:
            tokenizer.pad_token = tokenizer.eos_token
        tokenizer.padding_side = "right"
        _log(f"[✅] FT model loaded.")

        # Load Base model nếu paired eval — phải load TRƯỚC khi gọi evaluation
        base_model = base_tokenizer = None
        print(f"[Debug] background_eval_task: base_hf_repo='{base_hf_repo}'")
        if base_hf_repo:
            _log(f"[🔄] Loading base model: {base_hf_repo}...")
            # Unload FT tạm để tránh OOM khi load 2 model
            del model; del tokenizer
            gc.collect(); torch.cuda.empty_cache()

            base_model, base_tokenizer = FastLanguageModel.from_pretrained(
                model_name=base_hf_repo,
                max_seq_length=max(model_max_length, 4096),
                load_in_4bit=True,
            )
            if getattr(base_tokenizer, "pad_token", None) is None:
                base_tokenizer.pad_token = base_tokenizer.eos_token
            base_tokenizer.padding_side = "right"
            _log(f"[✅] Base model loaded.")

            # Reload FT model
            _log(f"[🔄] Reloading FT model: {hf_repo_id}...")
            model, tokenizer = FastLanguageModel.from_pretrained(
                model_name=hf_repo_id,
                max_seq_length=max(model_max_length, 4096),
                load_in_4bit=True,
                token=hf_token or None,
            )
            if getattr(tokenizer, "pad_token", None) is None:
                tokenizer.pad_token = tokenizer.eos_token
            tokenizer.padding_side = "right"
            _log(f"[✅] FT model reloaded.")

        eval_jobs_db[eval_job_id]['status'] = 'EVALUATING'
        _log(f"[📊] Bắt đầu đánh giá: {eval_file_path}")

        _run_evaluation_for_eval_job(
            eval_job_id=eval_job_id,
            job_id=job_id,
            eval_file_path=eval_file_path,
            model=model,
            tokenizer=tokenizer,
            model_max_length=model_max_length,
            log_fn=_log,
            judge_model=judge_model,
            base_model=base_model,
            base_tokenizer=base_tokenizer,
            base_model_repo=base_hf_repo,
            ft_model_repo=hf_repo_id,
        )

        _log("[✅] Hoàn thành Eval.")
        eval_jobs_db[eval_job_id]['status'] = 'COMPLETED'

    except Exception as e:
        _log(f"[❌] LỖI EVAL: {e}")
        eval_jobs_db[eval_job_id].update({'status': 'FAILED', 'error': str(e)})

    finally:
        if 'base_model' in locals() and base_model is not None:
            del base_model
        if 'base_tokenizer' in locals() and base_tokenizer is not None:
            del base_tokenizer
        if 'model' in locals() and model is not None:
            del model
        if 'tokenizer' in locals() and tokenizer is not None:
            del tokenizer
        model = None
        tokenizer = None
        _release_gpu_memory()
        if eval_file_path and os.path.exists(eval_file_path):
            os.remove(eval_file_path)
            print(f"[🗑️] Đã xóa eval file tạm: {eval_file_path}")
        _eval_slot_release()
        print(f"[Worker] Slot released — active={_active_eval_count}/{GPU_EVAL_SLOTS}")


def _run_evaluation_for_eval_job(eval_job_id, job_id, eval_file_path,
                                  model, tokenizer, model_max_length, log_fn,
                                  judge_model=DEFAULT_JUDGE_MODEL,
                                  base_model=None, base_tokenizer=None,
                                  base_model_repo=None, ft_model_repo=None):
    _tmp_key = f"__eval_tmp_{eval_job_id}"
    jobs_db[_tmp_key] = {'status': 'EVALUATING', 'logs': []}
    try:
        run_auto_evaluation(
            job_id=_tmp_key,
            eval_job_id=eval_job_id,
            eval_file_path=eval_file_path,
            active_model=model,
            tokenizer=tokenizer,
            max_seq=model_max_length,
            judge_model=judge_model,
            base_model=base_model,
            base_tokenizer=base_tokenizer,
            base_model_repo=base_model_repo,
            ft_model_repo=ft_model_repo,
        )
        raw_result = jobs_db[_tmp_key].get('eval_result')
        if raw_result:
            raw_result['jobId'] = job_id
            raw_result['modelEvalId'] = eval_job_id
            eval_jobs_db.setdefault(eval_job_id, {})['result'] = raw_result
        else:
            raise RuntimeError("run_auto_evaluation hoàn thành nhưng không có eval_result")
    finally:
        jobs_db.pop(_tmp_key, None)


_service = ClusteringService()








@app.route('/api/train/start', methods=['POST'])
def start_training():
    config_str = request.form.get('config')
    if not config_str: return jsonify({"error": "Missing 'config' in form data"}), 400

    try: parsed_config = json.loads(config_str)
    except json.JSONDecodeError: return jsonify({"error": "Invalid config JSON format"}), 400

    job_id = parsed_config.get('job_id')
    if not job_id: return jsonify({"error": "Missing 'job_id' in config"}), 400

    config = {
        'model_name': parsed_config.get('model_name', "unsloth/Qwen2.5-7B-Instruct-bnb-4bit"),
        'epochs': int(parsed_config.get('epochs', 1)),
        'batchSize': int(parsed_config.get('batchSize', 2)),
        'learningRate': float(parsed_config.get('learningRate', 2e-4)),
        'modelMaxLength': int(parsed_config.get('modelMaxLength', 2048)),
        'r': int(parsed_config.get('r', 16)),
        'lora_alpha': int(parsed_config.get('lora_alpha', 16)),
        'lora_dropout': float(parsed_config.get('lora_dropout', 0)),
        'random_state': int(parsed_config.get('random_state', 3407)),
        'gradient_accumulation_steps': int(parsed_config.get('gradient_accumulation_steps', 4)),
        'warmup_steps': int(parsed_config.get('warmup_steps', 5)),
        'dataset_hf_id': parsed_config.get('dataset_hf_id'),
        'push_to_hub': parsed_config.get('push_to_hub', False),
        'hf_repo_id': parsed_config.get('hf_repo_id'),
        'optim': parsed_config.get('optim', 'adamw_8bit'),
        'weight_decay': float(parsed_config.get('weight_decay', 0.01)),
        'lr_scheduler_type': parsed_config.get('lr_scheduler_type', 'linear'),
        'seed': int(parsed_config.get('seed', 3407)),
        'early_stopping_loss': float(parsed_config.get('early_stopping_loss', 0.5)),
        'early_stopping_patience': int(parsed_config.get('early_stopping_patience', 100)),
        'column_mapping': parsed_config.get('column_mapping') or parsed_config.get('columnMapping'),
    }

    # Ưu tiên token từ request, fallback sang Docker Secret / env HF_TOKEN
    hf_token = parsed_config.get('hf_token') or _read_secret("HF_TOKEN")

    # print("HF token:", hf_token)

    file_path = None
    if 'file' in request.files:
        file = request.files['file']
        if file.filename != '':
            file_path = os.path.join(UPLOAD_FOLDER, f"{job_id}_{secure_filename(file.filename)}")
            file.save(file_path)

    if not file_path and not config.get('dataset_hf_id'):
        return jsonify({"error": "Either a dataset file must be uploaded or 'dataset_hf_id' must be provided in the config."}), 400

    # THÊM JOB VÀO HÀNG ĐỢI THAY VÌ CHẠY NGAY LẬP TỨC
    job_queue.append((job_id, config, file_path, hf_token))
    jobs_db[job_id] = {'status': 'QUEUED', 'progress': 0, 'logs': [f"Job {job_id} is in queue."]}

    return jsonify({"message": "Job queued successfully", "job_id": job_id}), 202


@app.route('/api/train/status/<job_id>')
def get_status(job_id):
    global last_heartbeat
    last_heartbeat = time.time()
    return jsonify(jobs_db.get(job_id, {"status": "NOT_FOUND"})), 200
@app.route('/api/system/resources')
def get_system_resources():
    """Trả về thông số VRAM và GPU Utilization hiện tại cho giao diện AutoTrain."""
    vram_used, vram_total, gpu_util = get_gpu_stats()
    return jsonify({
        "vram_used_mb": vram_used,
        "vram_total_mb": vram_total,
        "gpu_util": gpu_util
    }), 200


@app.route('/api/train/stop/<job_id>', methods=['POST'])
def stop_training(job_id):
    # This is a bit tricky since trainer.train() is blocking in the thread.
    # However, we have WatchdogCallback and we can manually set a flag if needed.
    # For now, let's just update the status so the user knows we acknowledged it.
    if job_id in jobs_db:
        jobs_db[job_id]['status'] = 'STOPPED'
        jobs_db[job_id]['logs'].append("🛑 Stop request received. Training will halt at the next step.")
        return jsonify({"message": "Stop signal sent"}), 200
    return jsonify({"error": "Job not found"}), 404


@app.route('/api/eval/start', methods=['POST'])
def start_eval():
    """
    POST /api/eval/start  (multipart/form-data)
    Form fields:
      - config (JSON string):
          {
            eval_job_id:     string   — ID do Node backend tạo
            job_id:          string   — TrainingHistory jobId (để link kết quả)
            hf_repo_id:      string   — HuggingFace repo chứa fine-tuned model
            hf_token:        string   — HF token (nếu repo private)
            model_max_length: number  — max_seq_length khi load model
            judge_model:     string   — Claude model dùng làm judge (optional)
          }
      - eval_file: file    — dataset đánh giá (.json / .jsonl)

    Response 201:
      { "message": "Eval job started", "eval_job_id": "..." }
    """
    config_str = request.form.get('config')
    if not config_str:
        return jsonify({"error": "Missing 'config' in form data"}), 400

    try:
        cfg = json.loads(config_str)
    except json.JSONDecodeError:
        return jsonify({"error": "Invalid config JSON"}), 400

    eval_job_id   = cfg.get('eval_job_id')
    job_id        = cfg.get('job_id')
    hf_repo_id    = cfg.get('hf_repo_id')
    hf_token      = cfg.get('hf_token', '')
    model_max_len = int(cfg.get('model_max_length', 2048))
    judge_model   = cfg.get('judge_model', DEFAULT_JUDGE_MODEL)
    base_hf_repo  = cfg.get('base_model_hf_repo', '')

    print(f"[Debug] base_hf_repo = '{base_hf_repo}' | paired = {bool(base_hf_repo)}")

    if not eval_job_id:
        return jsonify({"error": "Missing 'eval_job_id' in config"}), 400
    if not job_id:
        return jsonify({"error": "Missing 'job_id' in config"}), 400
    if not hf_repo_id:
        return jsonify({"error": "Missing 'hf_repo_id' — model phải đã được push lên HF Hub"}), 400

    # ── GUARD: chặn eval nếu đang có train job active (tránh OOM trên single GPU) ──
    active_train = any(
        v.get('status') == 'TRAINING'
        for k, v in jobs_db.items()
        if not k.startswith('__eval_tmp_')
    )
    if active_train:
        return jsonify({
            "error": "train_active",
            "message": "Đang có train job đang chạy. Eval sẽ gây OOM trên single GPU. Vui lòng chờ train hoàn tất."
        }), 409

    # Lưu eval file
    if 'eval_file' not in request.files or request.files['eval_file'].filename == '':
        return jsonify({"error": "Missing 'eval_file'"}), 400

    efile = request.files['eval_file']
    eval_file_path = os.path.join(
        UPLOAD_FOLDER,
        f"{eval_job_id}_{secure_filename(efile.filename)}"
    )
    efile.save(eval_file_path)

    # --- check slot trước khi nhận job ---
    if not _eval_slot_acquire():
        return jsonify({
            "error": "worker_busy",
            "message": f"Worker đang chạy {_active_eval_count}/{GPU_EVAL_SLOTS} eval job. Vui lòng thử lại sau.",
            "active_slots": _active_eval_count,
            "max_slots": GPU_EVAL_SLOTS,
        }), 409

    # Từ chối nếu eval_job_id đã đang chạy
    if eval_job_id in eval_jobs_db and eval_jobs_db[eval_job_id].get('status') in ('RUNNING', 'EVALUATING'):
        _eval_slot_release()
        return jsonify({"error": f"Eval job {eval_job_id} đang chạy"}), 409

    eval_jobs_db[eval_job_id] = {
        'status':   'PENDING',
        'progress': 0,
        'logs':     [],
        'job_id':   job_id,
    }

    threading.Thread(
        target=background_eval_task,
        args=(eval_job_id, job_id, hf_repo_id, hf_token, eval_file_path,
              model_max_len, judge_model, base_hf_repo),
        daemon=True,
    ).start()

    return jsonify({"message": "Eval job started", "eval_job_id": eval_job_id}), 201



@app.route('/api/eval/status/<eval_job_id>', methods=['GET'])
def get_eval_status(eval_job_id):
    entry = eval_jobs_db.get(eval_job_id)
    if not entry:
        return jsonify({"status": "NOT_FOUND"}), 404

    return jsonify({
        "status":        entry.get('status', 'UNKNOWN'),
        "progress":      entry.get('progress', 0),
        "stage":         entry.get("stage", ""),
        "stage_label":   entry.get("stage_label", ""),
        "stage_detail":  entry.get("stage_detail", ""),
        "stage_current": entry.get("stage_current", 0),
        "stage_total":   entry.get("stage_total", 0),
        "logs":          entry.get('logs', []),
        **({"current_sample": entry["current_sample"]} if "current_sample" in entry else {}),
        **({"error": entry["error"]} if "error" in entry else {}),
    }), 200



@app.route('/api/eval/result/<eval_job_id>', methods=['GET'])
def get_eval_result_v2(eval_job_id):
    """
    GET /api/eval/result/:eval_job_id
    Trả về kết quả eval sau khi COMPLETED.
    Node backend gọi endpoint này 1 lần sau khi status = COMPLETED
    để POST lên /api/eval/save và lưu vào MongoDB.
    Response 202: eval chưa xong
    Response 200: { evalId, jobId, status, totalSamples, results, summary, ... }
    Response 404: eval_job_id không tồn tại
    """
    entry = eval_jobs_db.get(eval_job_id)
    if not entry:
        return jsonify({"error": "Eval job không tồn tại"}), 404

    status = entry.get('status')
    if status in ('PENDING', 'RUNNING', 'EVALUATING'):
        return jsonify({"status": status}), 202

    if status == 'FAILED':
        return jsonify({"status": "FAILED", "error": entry.get('error', '')}), 200

    result = entry.get('result')
    if not result:
        return jsonify({"status": "PENDING"}), 202

    return jsonify(result), 200


from transformers import AutoTokenizer, AutoModelForCausalLM
@app.route('/api/model/load', methods=['POST'])
def load_model():
    data = request.json
    hf_model_id = data.get('hf_model_id')
    instance_id = data.get('instance_id') or data.get('instanceId') or 1
    slot_id = int(instance_id)
    force_reload = data.get('force_reload', False)

    if not hf_model_id:
        return jsonify({"error": "Missing hf_model_id"}), 400
    if slot_id not in _slot_locks:
        return jsonify({"error": f"instanceId phải là 1 hoặc 2, nhận: {slot_id}"}), 400

    lock = _slot_locks[slot_id]
    if not lock.acquire(blocking=False):
        return jsonify({"error": f"Slot {slot_id} đang bận. Thử lại sau."}), 409

    try:
        current = _model_slots.get(slot_id)
        if current and current["model_id"] == hf_model_id and not force_reload:
            return jsonify({
                "status": "success",
                "message": f"Model đã được load ở slot {slot_id}, bỏ qua."
            }), 200

        if current:
            _release_slot(slot_id)

        print(f"[Slot {slot_id}] Loading {hf_model_id}...")

        # ✅ Dùng FastLanguageModel thay vì AutoModelForCausalLM
        # — tương thích cả model gốc HF lẫn model đã fine-tune bằng unsloth
        model, tokenizer = FastLanguageModel.from_pretrained(
            model_name=hf_model_id,
            max_seq_length=2048,
            load_in_4bit=True,
            dtype=None,  # auto-detect
        )
        FastLanguageModel.for_inference(model)  # tăng tốc inference

        _model_slots[slot_id] = {
            "model_id": hf_model_id,
            "model": model,
            "tokenizer": tokenizer
        }

        return jsonify({
            "status": "success",
            "message": f"Model {hf_model_id} loaded vào slot {slot_id}."
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

    finally:
        lock.release()


@app.route('/api/model/unload/<int:slot_id>', methods=['POST'])
def unload_model(slot_id):
    lock = _slot_locks.get(slot_id)
    if not lock:
        return jsonify({"error": "Invalid slot"}), 400
    with lock:
        _release_slot(slot_id)
    return jsonify({"status": "success", "message": f"Slot {slot_id} unloaded"}), 200


@app.route('/api/infer/stop/<int:slot_id>', methods=['POST'])
def stop_inference(slot_id):
    if slot_id not in _slot_abort_events:
        return jsonify({"error": "Invalid slot"}), 400
    _slot_abort_events[slot_id].set()
    return jsonify({"status": "stop signal sent"}), 200


@app.route('/api/infer/stream', methods=['POST'])
def infer_model_stream():
    global inference_logs_db

    data        = request.json
    print(f"[infer_stream] raw body keys: {list(data.keys())}")
    print(f"[infer_stream] instanceId field: {data.get('instanceId')!r}")

    instance_id = data.get('instance_id') or data.get('instanceId') or 1
    slot_id = int(instance_id)
    print(f"[infer_stream] → resolved slot_id={slot_id}")

    if slot_id not in _slot_locks:
        return jsonify({"error": f"instanceId phải là 1 hoặc 2, nhận: {slot_id}"}), 400

    slot = _model_slots.get(slot_id)
    if slot is None:
        return jsonify({"error": f"Slot {slot_id}: chưa load model. Gọi /api/model/load trước."}), 400

    model      = slot["model"]
    tokenizer  = slot["tokenizer"]
    loaded_id  = slot["model_id"]

    text_input    = data.get('text_input')
    system_prompt = data.get('system_prompt', DEFAULT_SYSTEM_PROMPT)

    # --- HISTORY: parse & normalize ---
    raw_history = data.get('history', [])
    history = normalize_history(raw_history, max_messages=10)

    hf_model_id = data.get('hf_model_id')
    if hf_model_id and hf_model_id != loaded_id:
        return jsonify({"error": f"Model mismatch. Slot {slot_id} đang chạy {loaded_id}, bạn gửi {hf_model_id}."}), 400

    if not text_input:
        return jsonify({"error": "Missing text_input"}), 400

    # Parse tham số generation
    gen_max_new_tokens     = data.get('max_new_tokens', 512)
    gen_temperature        = data.get('temperature', 0.3)
    gen_top_k              = data.get('top_k', 40)
    gen_top_p              = data.get('top_p', 0.85)
    gen_repetition_penalty = data.get('repetition_penalty', 1.15)
    gen_do_sample          = data.get('do_sample', True)

    print(f"[Slot {slot_id}] System prompt: {system_prompt}")
    print(f"[Slot {slot_id}] history_count={len(history)}, "
          f"max_new_tokens={gen_max_new_tokens}, temperature={gen_temperature}, "
          f"top_k={gen_top_k}, top_p={gen_top_p}, rep_penalty={gen_repetition_penalty}")

    inference_id = str(uuid.uuid4())
    inference_logs_db[inference_id] = {
        "inference_id": inference_id,
        "timestamp":    datetime.datetime.now().isoformat(),
        "slot_id":      slot_id,
        "model_id":     loaded_id,
        "input_parameters": {
            "text_input":          text_input,
            "system_prompt":       system_prompt,
            "history":             history,           # <-- thêm
            "history_count":       len(history),      # <-- thêm
            "max_new_tokens":      gen_max_new_tokens,
            "temperature":         gen_temperature,
            "top_k":               gen_top_k,
            "top_p":               gen_top_p,
            "repetition_penalty":  gen_repetition_penalty,
            "do_sample":           gen_do_sample,
        },
        "generated_text": "",
        "status": "started",
    }

    lock = _slot_locks[slot_id]

    try:
        # --- dùng history khi build prompt ---
        instruction_text = format_inference_prompt(tokenizer, system_prompt, history, text_input)

        inputs = tokenizer(
            text=instruction_text,
            return_tensors="pt",
        ).to("cuda")

        streamer = TextIteratorStreamer(tokenizer, skip_prompt=True, skip_special_tokens=True)

        generation_kwargs = dict(
            **inputs,
            streamer=streamer,
            max_new_tokens=gen_max_new_tokens,          # ✅ dùng đúng tên biến
            temperature=gen_temperature,
            top_k=gen_top_k,
            top_p=gen_top_p,
            repetition_penalty=gen_repetition_penalty,
            do_sample=gen_do_sample,
        )

        def _run_generate():
            with lock:
                model.generate(**generation_kwargs)

        # ✅ Thứ tự đúng: clear → add stopping_criteria → start thread
        _slot_abort_events[slot_id].clear()
        generation_kwargs["stopping_criteria"] = StoppingCriteriaList([
            AbortStoppingCriteria(_slot_abort_events[slot_id])
        ])
        Thread(target=_run_generate, daemon=True).start()   # ✅ Chỉ start 1 lần

        def generate_stream():
            full_response = []
            for text in stream_without_thinking(streamer):
                full_response.append(text)
                yield f"data: {json.dumps({'text': text}, ensure_ascii=False)}\n\n"
            inference_logs_db[inference_id]["generated_text"] = "".join(full_response)
            inference_logs_db[inference_id]["status"] = "completed"
            yield "data: [DONE]\n\n"

        return Response(generate_stream(), mimetype='text/event-stream')

    except Exception as e:
        traceback.print_exc()
        inference_logs_db[inference_id]["status"] = "error"
        inference_logs_db[inference_id]["error_message"] = str(e)
        return jsonify({"error": str(e)}), 500


@app.route('/api/infer/logs', methods=['GET'])
@app.route('/api/infer/logs/<inference_id>', methods=['GET'])
def get_inference_logs(inference_id=None):
    global inference_logs_db

    if inference_id:
        log = inference_logs_db.get(inference_id)
        if log:
            return jsonify(log), 200
        else:
            return jsonify({"error": "Inference log not found"}), 404
    else:
        # Return all logs, perhaps with pagination in a real-world scenario
        return jsonify(list(inference_logs_db.values())), 200


@app.route('/api/system-eval/resources')
def get_resources():
    info = pynvml.nvmlDeviceGetMemoryInfo(gpu_handle)
    util = pynvml.nvmlDeviceGetUtilizationRates(gpu_handle)
    vram_used_mb  = info.used   // 1024 ** 2
    vram_total_mb = info.total  // 1024 ** 2
    vram_free_mb  = info.free   // 1024 ** 2

    with _active_eval_lock:
        active = _active_eval_count

    # Ngưỡng VRAM tối thiểu để nhận thêm 1 eval job (MB)
    VRAM_MIN_FREE_MB = 5120  # 5 GB

    can_create = (active < GPU_EVAL_SLOTS) and (vram_free_mb >= VRAM_MIN_FREE_MB)

    return jsonify({
        "vram_used_mb":    vram_used_mb,
        "vram_total_mb":   vram_total_mb,
        "vram_free_mb":    vram_free_mb,
        "gpu_util":        util.gpu,
        "active_evals":    active,
        "max_evals":       GPU_EVAL_SLOTS,
        "can_create_eval": can_create,
        "vram_min_free_mb": VRAM_MIN_FREE_MB,
    }), 200


@app.route("/api/cluster", methods=["POST"])
def cluster():
    """
    POST /api/cluster

    Phải gọi /api/cluster/visualize trước (để có embedding cache).
    Chạy DBSCAN lọc noise + KMeans phân cụm, lưu toàn bộ kết quả vào
    _cluster_cache để các bước filter sau có thể đọc độc lập.

    Body JSON:
    {
        "k":           11,   // Tùy chọn, số cụm KMeans,      mặc định 11
        "eps":         0.05, // Tùy chọn, DBSCAN eps,         mặc định 0.05
        "min_samples": 3     // Tùy chọn, DBSCAN min_samples, mặc định 3
    }

    Response JSON:
    {
        "data":        [ { ...original_item, "cluster": int }, ... ],
        "assignments": [ int, ... ],   // -1 = noise, 0..K-1 = cụm KMeans
        "groups":      [ { "groupId": int, "count": int, "label": str }, ... ],
        "clusterStats": [              // trung bình cosine similarity theo từng cụm
            { "clusterId": int, "avgSimilarity": float, "count": int }, ...
        ],
        "avgSimilarity": float         // trung bình cosine similarity toàn bộ tập clean
    }
    """
    body = request.get_json(silent=True) or {}

    k = body.get("k", 11)
    if not isinstance(k, int) or k < 1:
        return jsonify({"error": "'k' phải là số nguyên dương."}), 400

    eps = body.get("eps", 0.05)
    if not isinstance(eps, (int, float)) or eps <= 0:
        return jsonify({"error": "'eps' phải là số thực dương."}), 400

    min_samples = body.get("min_samples", 3)
    if not isinstance(min_samples, int) or min_samples < 1:
        return jsonify({"error": "'min_samples' phải là số nguyên dương."}), 400

    try:
        result = _service.cluster(
            k=int(k),
            eps=float(eps),
            min_samples=int(min_samples),
        )
        return jsonify(result), 200

    except RuntimeError as re:
        return jsonify({"error": str(re)}), 400
    except ValueError as ve:
        return jsonify({"error": str(ve)}), 400
    except Exception as exc:
        app.logger.exception("Lỗi trong /api/cluster")
        return jsonify({"error": f"Lỗi server: {str(exc)}"}), 500


@app.route("/api/cluster/filter", methods=["POST"])
def cluster_filter():
    """
    POST /api/cluster/filter

    Body JSON:
    {
        "threshold": 0.9  // Tùy chọn, mặc định 0.9
    }
    """
    body = request.get_json(silent=True) or {}
    threshold = body.get("threshold", 0.9)
    if not isinstance(threshold, (int, float)) or not (0 < threshold <= 1):
        return jsonify({"error": "'threshold' phải là số thực trong khoảng (0, 1]."}), 400

    try:
        result = _service.filter_by_centroid(threshold=float(threshold))
        return jsonify(result), 200
    except RuntimeError as re:
        return jsonify({"error": str(re)}), 400
    except Exception as exc:
        app.logger.exception("Lỗi trong /api/cluster/filter")
        return jsonify({"error": f"Lỗi server: {str(exc)}"}), 500


@app.route("/api/cluster/remove-noise", methods=["POST"])
def cluster_filter_remove_noise():
    """
    POST /api/cluster/remove-noise

    Phải gọi /api/cluster trước (để có cluster cache).
    Lọc bỏ toàn bộ điểm bị DBSCAN đánh nhãn noise (cluster == -1),
    trả về phần còn lại với nhãn cụm KMeans nguyên vẹn.

    Không có tham số. Hoạt động độc lập với /deduplicate.

    Response JSON:
    {
        "data":         [ { ...original_item, "cluster": int }, ... ],
        "assignments":  [ int, ... ],   // chỉ còn 0..K-1, không còn -1
        "groups":       [ { "groupId": int, "count": int, "label": str }, ... ],
        "removedCount": int,            // số điểm noise bị loại
        "keptCount":    int             // số điểm còn lại
    }
    """
    try:
        result = _service.filter_remove_noise()
        return jsonify(result), 200

    except RuntimeError as re:
        return jsonify({"error": str(re)}), 400
    except Exception as exc:
        app.logger.exception("Lỗi trong /api/cluster/remove-noise")
        return jsonify({"error": f"Lỗi server: {str(exc)}"}), 500


@app.route("/api/cluster/deduplicate", methods=["POST"])
def cluster_filter_deduplicate():
    """
    POST /api/cluster/deduplicate

    Phải gọi /api/cluster trước (để có cluster cache).
    Loại bỏ các điểm có cosine similarity với tâm cụm > threshold
    (tức là quá giống nhau / trùng lặp), luôn giữ lại điểm gần tâm
    nhất của mỗi cụm. Điểm noise (cluster == -1) bị bỏ qua hoàn toàn.

    Hoạt động độc lập với /remove-noise.

    Body JSON:
    {
        "threshold": 0.9  // Tùy chọn, mặc định 0.9 — khoảng (0, 1]
    }

    Response JSON:
    {
        "data":         [ { ...original_item, "cluster": int }, ... ],
        "assignments":  [ int, ... ],
        "groups":       [ { "groupId": int, "count": int, "label": str }, ... ],
        "removedCount": int,   // số điểm bị loại do quá gần tâm cụm
        "keptCount":    int    // số điểm còn lại
    }
    """
    body = request.get_json(silent=True) or {}

    threshold = body.get("threshold", 0.9)
    if not isinstance(threshold, (int, float)) or not (0 < threshold <= 1):
        return jsonify({"error": "'threshold' phải là số thực trong khoảng (0, 1]."}), 400

    try:
        result = _service.filter_deduplicate(threshold=float(threshold))
        return jsonify(result), 200

    except RuntimeError as re:
        return jsonify({"error": str(re)}), 400
    except Exception as exc:
        app.logger.exception("Lỗi trong /api/cluster/deduplicate")
        return jsonify({"error": f"Lỗi server: {str(exc)}"}), 500


@app.route("/api/cluster/visualize", methods=["POST"])
def cluster_visualize():
    """
    POST /api/cluster/visualize

    Body JSON:
    {
        "data":        [ <sample>, ... ],  // Bắt buộc  (OpenAI messages format)
        "max_k":       20,                 // Tùy chọn, mặc định 20
        "eps":         0.1,               // Tùy chọn, DBSCAN eps, mặc định 0.1
        "min_samples": 3                   // Tùy chọn, DBSCAN min_samples, mặc định 3
    }

    Response JSON:
    {
        "elbow":      [ { "k": int, "wcss": float }, ... ],
        "silhouette": [ { "k": int, "silhouette": float }, ... ],
        "kDistance":  [ { "rank": int, "distance": float }, ... ],
        "pointCount": int,
        "noiseCount": int
    }

    Side-effect: lưu conv_embeddings vào cache để /api/cluster tái sử dụng.
    """
    body = request.get_json(silent=True)
    if not body:
        return jsonify({"error": "Request body phải là JSON hợp lệ."}), 400

    data = body.get("data")
    if not isinstance(data, list) or len(data) == 0:
        return jsonify({"error": "'data' phải là một mảng không rỗng."}), 400

    max_k = body.get("max_k", 20)
    if not isinstance(max_k, int) or max_k < 1:
        return jsonify({"error": "'max_k' phải là số nguyên dương."}), 400

    eps = body.get("eps", 0.15)
    if not isinstance(eps, (int, float)) or eps <= 0:
        return jsonify({"error": "'eps' phải là số thực dương (ví dụ: 0.15)."}), 400

    min_samples = body.get("min_samples", 6)
    if not isinstance(min_samples, int) or min_samples < 1:
        return jsonify({"error": "'min_samples' phải là số nguyên dương."}), 400

    try:
        result = _service.visualize(
            data=data,
            max_k=max_k,
            eps=float(eps),
            min_samples=int(min_samples),
        )
        return jsonify(result), 200

    except ValueError as ve:
        return jsonify({"error": str(ve)}), 400
    except Exception as exc:
        app.logger.exception("Lỗi trong /api/cluster/visualize")
        return jsonify({"error": f"Lỗi server: {str(exc)}"}), 500


@app.route("/api/cluster/cache", methods=["DELETE"])
def clear_cache():
    """DELETE /api/cluster/cache — Xóa toàn bộ embedding + cluster cache."""
    _service.clear_cache()
    return jsonify({"message": "Cache đã được xóa."}), 200


# ── Health-check ──────────────────────────────────────────────────────────────

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "device": _service.device}), 200


# clustering_service = ClusteringService()

@app.route("/api/cluster/safe-split", methods=["POST"])
def cluster_safe_split():
    """
    POST /api/cluster/safe-split

    Body JSON:
    {
        "data": [ <sample>, ... ],      // bắt buộc
        "test_percentage": 20,          // tùy chọn, mặc định 20
        "threshold": 0.85,              // tùy chọn, mặc định 0.85
        "max_attempts": 20,             // tùy chọn, mặc định 20
        "seed": 42                      // tùy chọn, mặc định 42
    }
    """
    try:
        body = request.get_json(force=True) or {}
        data = body.get("data")
        test_percentage = body.get("test_percentage", 20)
        threshold = body.get("threshold", 0.85)
        max_attempts = body.get("max_attempts", 20)
        seed = body.get("seed", 42)

        if not isinstance(data, list) or len(data) == 0:
            return jsonify({"error": "Missing or empty data array"}), 400

        result = _service.safe_split(
            data=data,
            test_percentage=float(test_percentage),
            threshold=float(threshold),
            max_attempts=int(max_attempts),
            seed=int(seed),
        )
        return jsonify(result), 200

    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e) or "Failed to generate safe split"}), 500



# ======================================================================
# 5. MAIN SERVER STARTUP
# ======================================================================

if __name__ == '__main__':
    PORT = int(os.environ.get("PORT", 5000))
    HOST = os.environ.get("HOST", "0.0.0.0")

    print("=" * 60)
    print("🚀 GPU Service đang khởi động...")
    print(f"   Host : {HOST}")
    print(f"   Port : {PORT}")
    print(f"   BACKEND_URL      : {_read_secret('BACKEND_URL') or '(chưa set)'}")
    print(f"   ANTHROPIC_API_KEY: {'✅ đã set' if _read_secret('ANTHROPIC_API_KEY') else '❌ chưa set'}")
    print("=" * 60)

    # Chạy Background Job Manager
    manager_thread = threading.Thread(target=job_manager_thread, daemon=True)
    manager_thread.start()
    print("✅ Job Manager đã sẵn sàng.")

    # Chạy Flask Server
    print(f"🔥 Flask Server đang lắng nghe trên {HOST}:{PORT} ...")
    app.run(host=HOST, port=PORT, debug=False, use_reloader=False)
