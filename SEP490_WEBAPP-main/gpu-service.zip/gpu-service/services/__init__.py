"""Standalone services (clustering)."""
